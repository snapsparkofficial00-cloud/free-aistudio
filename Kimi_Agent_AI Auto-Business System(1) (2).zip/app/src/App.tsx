import { Routes, Route } from 'react-router'
import { AppLayout } from './components/layout/AppLayout'
import Dashboard from './pages/Dashboard'
import Agents from './pages/Agents'
import Commands from './pages/Commands'
import Pipeline from './pages/Pipeline'
import Memory from './pages/Memory'
import Settings from './pages/Settings'

export default function App() {
  return (
    <Routes>
      <Route element={<AppLayout />}>
        <Route path="/" element={<Dashboard />} />
        <Route path="/agents" element={<Agents />} />
        <Route path="/commands" element={<Commands />} />
        <Route path="/pipeline" element={<Pipeline />} />
        <Route path="/memory" element={<Memory />} />
        <Route path="/settings" element={<Settings />} />
      </Route>
    </Routes>
  )
}
