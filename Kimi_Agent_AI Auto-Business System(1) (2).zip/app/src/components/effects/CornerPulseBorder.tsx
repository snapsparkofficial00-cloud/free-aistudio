import type { ReactNode } from 'react'

interface CornerPulseBorderProps {
  children: ReactNode
  className?: string
}

export function CornerPulseBorder({ children, className = '' }: CornerPulseBorderProps) {
  return (
    <div className={`corner-pulse-wrapper ${className}`}>
      <div className="relative z-10">
        {children}
      </div>
    </div>
  )
}
