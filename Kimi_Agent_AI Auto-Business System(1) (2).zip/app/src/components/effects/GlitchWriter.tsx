import { useState, useEffect, useRef } from 'react'

const STRINGS = [
  "ANALYZING MARKETS",
  "OPTIMIZING GAS FEES",
  "GENERATING CREATIVE ASSETS",
  "SELF-REPAIRING MODULES",
  "SYNCING NEURAL WEIGHTS",
  "HARVESTING YIELD",
]

export function GlitchWriter() {
  const [display, setDisplay] = useState("")
  const indexRef = useRef(0)
  const charIndexRef = useRef(0)
  const isDeletingRef = useRef(false)
  const pauseRef = useRef(false)

  useEffect(() => {
    const interval = setInterval(() => {
      if (pauseRef.current) return

      const currentString = STRINGS[indexRef.current]
      const isDeleting = isDeletingRef.current

      if (!isDeleting) {
        // Typing
        const targetChar = currentString.slice(0, charIndexRef.current + 1)
        const glitch = Math.random() > 0.9
        if (glitch && targetChar.length > 0) {
          const randomChar = String.fromCharCode(33 + Math.floor(Math.random() * 94))
          setDisplay(targetChar.slice(0, -1) + randomChar)
        } else {
          setDisplay(targetChar)
        }
        charIndexRef.current++

        if (display === currentString) {
          pauseRef.current = true
          setTimeout(() => {
            isDeletingRef.current = true
            pauseRef.current = false
          }, 2000)
        }
      } else {
        // Deleting
        charIndexRef.current = Math.max(0, charIndexRef.current - 1)
        setDisplay(currentString.slice(0, charIndexRef.current))

        if (charIndexRef.current === 0) {
          isDeletingRef.current = false
          indexRef.current = (indexRef.current + 1) % STRINGS.length
        }
      }
    }, 80)

    return () => clearInterval(interval)
  }, [display])

  return (
    <div className="flex items-center gap-2 font-mono text-sm text-[rgba(252,252,252,0.6)]">
      <span className="text-[#44f2d8]">&gt;</span>
      <span className="text-[#44f2d8]/70">{display}</span>
      <span className="w-2 h-4 bg-[#44f2d8] animate-pulse" />
    </div>
  )
}
