import { useRef, useEffect } from 'react'
import * as THREE from 'three'

const vertexShader = `
  uniform float time;
  varying vec3 vNormal;
  varying vec3 vPosition;

  float sineWave(vec3 position) {
    float x = 0.05 * sin(position.y * 6.0 + time);
    x += cos(position.z * 6.0 + time) * 0.03;
    return x;
  }

  void main() {
    vec3 newPosition = position;
    float displacement = sineWave(newPosition);
    newPosition += normal * displacement;
    vNormal = normalize(normalMatrix * normal);
    vPosition = (modelViewMatrix * vec4(newPosition, 1.0)).xyz;
    gl_Position = projectionMatrix * modelViewMatrix * vec4(newPosition, 1.0);
  }
`

const fragmentShader = `
  varying vec3 vNormal;
  varying vec3 vPosition;

  void main() {
    vec3 teal = vec3(0.267, 0.949, 0.847);
    vec3 lavender = vec3(0.506, 0.549, 0.973);
    float intensity = pow(0.6 - dot(vNormal, vec3(0.0, 0.0, 1.0)), 2.0);
    float colorMix = (vPosition.x + vPosition.y) * 0.5 + 0.5;
    vec3 finalColor = mix(teal, lavender, colorMix) * intensity;
    gl_FragColor.a = 0.6 * intensity;
    gl_FragColor.rgb = finalColor;
  }
`

export function NeuralSphere() {
  const canvasRef = useRef<HTMLCanvasElement>(null)

  useEffect(() => {
    const canvas = canvasRef.current
    if (!canvas) return

    // Scene setup
    const scene = new THREE.Scene()
    const camera = new THREE.PerspectiveCamera(75, window.innerWidth / window.innerHeight, 0.1, 100)
    camera.position.z = 2.5

    const renderer = new THREE.WebGLRenderer({ canvas, alpha: true, antialias: true })
    renderer.setSize(window.innerWidth, window.innerHeight)
    renderer.setPixelRatio(Math.min(window.devicePixelRatio, 2))

    // Geometry & Material
    const geometry = new THREE.IcosahedronGeometry(1, 64)
    const material = new THREE.ShaderMaterial({
      vertexShader,
      fragmentShader,
      uniforms: {
        time: { value: 0 },
      },
      wireframe: true,
      transparent: true,
      blending: THREE.AdditiveBlending,
    })

    const mesh = new THREE.Mesh(geometry, material)
    scene.add(mesh)

    // Mouse rotation
    let mouseDown = false
    let mouseX = 0
    let mouseY = 0
    let targetRotationX = 0
    let targetRotationY = 0

    const onMouseDown = (e: MouseEvent) => {
      mouseDown = true
      mouseX = e.clientX
      mouseY = e.clientY
    }
    const onMouseMove = (e: MouseEvent) => {
      if (!mouseDown) return
      targetRotationY += (e.clientX - mouseX) * 0.005
      targetRotationX += (e.clientY - mouseY) * 0.005
      mouseX = e.clientX
      mouseY = e.clientY
    }
    const onMouseUp = () => { mouseDown = false }

    canvas.addEventListener('mousedown', onMouseDown)
    canvas.addEventListener('mousemove', onMouseMove)
    canvas.addEventListener('mouseup', onMouseUp)

    // Animation loop
    let frameId: number
    const animate = () => {
      frameId = requestAnimationFrame(animate)
      material.uniforms.time.value += 0.01
      mesh.rotation.y += (targetRotationY - mesh.rotation.y) * 0.05
      mesh.rotation.x += (targetRotationX - mesh.rotation.x) * 0.05
      mesh.rotation.y += 0.001 // Auto rotation
      renderer.render(scene, camera)
    }
    animate()

    // Resize
    const onResize = () => {
      camera.aspect = window.innerWidth / window.innerHeight
      camera.updateProjectionMatrix()
      renderer.setSize(window.innerWidth, window.innerHeight)
    }
    window.addEventListener('resize', onResize)

    return () => {
      cancelAnimationFrame(frameId)
      canvas.removeEventListener('mousedown', onMouseDown)
      canvas.removeEventListener('mousemove', onMouseMove)
      canvas.removeEventListener('mouseup', onMouseUp)
      window.removeEventListener('resize', onResize)
      geometry.dispose()
      material.dispose()
      renderer.dispose()
    }
  }, [])

  return (
    <canvas
      ref={canvasRef}
      className="fixed inset-0 z-0 pointer-events-auto"
      style={{ opacity: 0.35 }}
    />
  )
}
