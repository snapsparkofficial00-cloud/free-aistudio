import { Outlet } from 'react-router'
import { Sidebar } from './Sidebar'
import { Header } from './Header'
import { NeuralSphere } from '../effects/NeuralSphere'

export function AppLayout() {
  return (
    <div className="min-h-screen bg-[#0a0a0a] relative">
      {/* Neural Sphere Background */}
      <NeuralSphere />

      {/* Sidebar */}
      <Sidebar />

      {/* Header */}
      <Header />

      {/* Main Content */}
      <main className="ml-64 pt-14 min-h-screen relative z-10">
        <div className="p-6">
          <Outlet />
        </div>
      </main>
    </div>
  )
}
