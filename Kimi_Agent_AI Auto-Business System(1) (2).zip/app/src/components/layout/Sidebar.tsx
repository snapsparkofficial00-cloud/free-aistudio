import { Link, useLocation } from 'react-router'
import {
  LayoutDashboard,
  Bot,
  Terminal,
  GitBranch,
  Brain,
  Settings,
  Zap,
  LogOut,
} from 'lucide-react'
import { trpc } from '@/providers/trpc'

const navItems = [
  { path: '/', label: 'Dashboard', icon: LayoutDashboard },
  { path: '/agents', label: 'AI Agents', icon: Bot },
  { path: '/commands', label: 'Command Center', icon: Terminal },
  { path: '/pipeline', label: 'Content Pipeline', icon: GitBranch },
  { path: '/memory', label: 'Neural Memory', icon: Brain },
  { path: '/settings', label: 'System Config', icon: Settings },
]

export function Sidebar() {
  const location = useLocation()
  const logout = trpc.auth.logout.useMutation()

  const handleLogout = () => {
    logout.mutate()
    window.location.reload()
  }

  return (
    <aside className="fixed left-0 top-0 h-full w-64 z-40 liquid-glass-strong border-r border-white/5 flex flex-col">
      {/* Logo */}
      <div className="px-6 py-5 border-b border-white/5">
        <Link to="/" className="flex items-center gap-3 group">
          <div className="w-9 h-9 rounded-lg bg-gradient-accent flex items-center justify-center shadow-glow">
            <Zap className="w-5 h-5 text-[#0a0a0a]" />
          </div>
          <div>
            <h1 className="text-sm font-bold tracking-wider text-[#fcfcfc]">NEXUS</h1>
            <p className="text-[10px] font-mono text-[#44f2d8] tracking-[0.2em]">AUTOMATA</p>
          </div>
        </Link>
      </div>

      {/* Navigation */}
      <nav className="flex-1 px-3 py-4 space-y-1">
        {navItems.map((item) => {
          const isActive = location.pathname === item.path
          const Icon = item.icon
          return (
            <Link
              key={item.path}
              to={item.path}
              className={`
                flex items-center gap-3 px-4 py-2.5 rounded-lg text-sm font-medium transition-all duration-200
                ${isActive
                  ? 'bg-[#44f2d8]/10 text-[#44f2d8] border border-[#44f2d8]/20 shadow-glow'
                  : 'text-[rgba(252,252,252,0.7)] hover:text-[#fcfcfc] hover:bg-white/5'
                }
              `}
            >
              <Icon className={`w-4 h-4 ${isActive ? 'text-[#44f2d8]' : ''}`} />
              {item.label}
              {isActive && (
                <div className="ml-auto w-1.5 h-1.5 rounded-full bg-[#44f2d8] shadow-[0_0_6px_rgba(68,242,216,0.6)]" />
              )}
            </Link>
          )
        })}
      </nav>

      {/* Footer */}
      <div className="px-4 py-4 border-t border-white/5 space-y-3">
        <div className="flex items-center gap-2 px-2">
          <div className="status-dot active" />
          <span className="text-xs font-mono text-[rgba(252,252,252,0.5)]">System Online</span>
        </div>
        <button
          onClick={handleLogout}
          className="flex items-center gap-2 px-4 py-2 w-full rounded-lg text-sm text-[rgba(252,252,252,0.5)] hover:text-[#ef4444] hover:bg-[#ef4444]/10 transition-all"
        >
          <LogOut className="w-4 h-4" />
          Disconnect
        </button>
      </div>
    </aside>
  )
}
