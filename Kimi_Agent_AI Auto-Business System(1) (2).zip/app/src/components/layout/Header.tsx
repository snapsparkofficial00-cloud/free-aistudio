import { Activity, CircleDollarSign } from 'lucide-react'
import { trpc } from '@/providers/trpc'

export function Header() {
  const { data: stats } = trpc.agent.getStats.useQuery()
  const { data: user } = trpc.auth.me.useQuery()

  return (
    <header className="fixed top-0 left-64 right-0 h-14 z-30 liquid-glass border-b border-white/5 flex items-center justify-between px-6">
      {/* Status */}
      <div className="flex items-center gap-3">
        <div className="flex items-center gap-2 px-3 py-1.5 rounded-full bg-[#44f2d8]/10 border border-[#44f2d8]/20">
          <Activity className="w-3.5 h-3.5 text-[#44f2d8]" />
          <span className="text-xs font-mono text-[#44f2d8] tracking-wide">AUTONOMOUS</span>
        </div>
        <span className="text-xs font-mono text-[rgba(252,252,252,0.4)]">
          {stats?.active || 0} agents active
        </span>
      </div>

      {/* Center Stats */}
      <div className="flex items-center gap-6">
        <div className="flex items-center gap-2">
          <CircleDollarSign className="w-3.5 h-3.5 text-[#44f2d8]" />
          <span className="text-xs font-mono text-[rgba(252,252,252,0.6)]">
            ${((stats?.totalEarnings || 0) / 1000).toFixed(1)}K earned
          </span>
        </div>
        <div className="h-4 w-px bg-white/10" />
        <div className="flex items-center gap-2">
          <span className="text-xs font-mono text-[#44f2d8]">+12.4%</span>
          <span className="text-xs font-mono text-[rgba(252,252,252,0.4)]">efficiency</span>
        </div>
      </div>

      {/* User */}
      <div className="flex items-center gap-3">
        <div className="text-right">
          <p className="text-xs font-medium text-[#fcfcfc]">{user?.name || 'Operator'}</p>
          <p className="text-[10px] font-mono text-[rgba(252,252,252,0.4)]">{user?.role || 'admin'}</p>
        </div>
        <div className="w-8 h-8 rounded-full bg-gradient-accent flex items-center justify-center text-[#0a0a0a] text-xs font-bold">
          {(user?.name || 'O')[0].toUpperCase()}
        </div>
      </div>
    </header>
  )
}
