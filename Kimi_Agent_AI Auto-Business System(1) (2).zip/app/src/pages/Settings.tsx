import { useState } from 'react'
import { motion } from 'framer-motion'
import {
  Settings as SettingsIcon,
  Link,
  CheckCircle,
  XCircle,
  Loader2,
  RefreshCw,
  Youtube,
  Facebook,
  Twitter,
  Instagram,
  Globe,
  ShoppingBag,
  Shield,
  KeyRound,
  Bell,
  Database,
} from 'lucide-react'
import { trpc } from '@/providers/trpc'

const PLATFORM_CONFIG: Record<string, { icon: any; color: string; name: string }> = {
  youtube: { icon: Youtube, color: 'text-red-400', name: 'YouTube' },
  facebook: { icon: Facebook, color: 'text-blue-400', name: 'Facebook' },
  twitter: { icon: Twitter, color: 'text-sky-400', name: 'Twitter / X' },
  instagram: { icon: Instagram, color: 'text-pink-400', name: 'Instagram' },
  website: { icon: Globe, color: 'text-green-400', name: 'Website' },
  shopify: { icon: ShoppingBag, color: 'text-emerald-400', name: 'Shopify' },
}

export default function Settings() {
  const utils = trpc.useUtils()
  const { data: platforms, isLoading } = trpc.platform.list.useQuery()
  const connect = trpc.platform.connect.useMutation({ onSuccess: () => utils.platform.list.invalidate() })
  const disconnect = trpc.platform.disconnect.useMutation({ onSuccess: () => utils.platform.list.invalidate() })
  const test = trpc.platform.test.useMutation()

  const [testingId, setTestingId] = useState<number | null>(null)

  const handleTest = async (id: number) => {
    setTestingId(id)
    await test.mutateAsync({ id })
    setTestingId(null)
  }

  const allPlatforms = ['youtube', 'facebook', 'twitter', 'instagram', 'website', 'shopify'] as const

  return (
    <div className="space-y-6 max-w-3xl">
      {/* Header */}
      <div>
        <h1 className="text-2xl font-bold text-[#fcfcfc] flex items-center gap-3">
          <SettingsIcon className="w-6 h-6 text-[#44f2d8]" />
          System Config
        </h1>
        <p className="text-sm font-mono text-[rgba(252,252,252,0.5)] mt-1">
          Manage platform connections and system preferences
        </p>
      </div>

      {/* Platform Connections */}
      <div className="liquid-glass rounded-xl p-5">
        <h3 className="text-sm font-semibold text-[#fcfcfc] flex items-center gap-2 mb-4">
          <Link className="w-4 h-4 text-[#44f2d8]" />
          Platform Connections
        </h3>

        {isLoading ? (
          <div className="flex items-center justify-center h-20">
            <Loader2 className="w-5 h-5 text-[#44f2d8] animate-spin" />
          </div>
        ) : (
          <div className="space-y-3">
            {allPlatforms.map((platformKey) => {
              const config = PLATFORM_CONFIG[platformKey]
              const Icon = config.icon
              const connected = platforms?.find(p => p.platform === platformKey)
              const isConnected = connected?.status === 'connected'

              return (
                <motion.div
                  key={platformKey}
                  initial={{ opacity: 0, x: -10 }}
                  animate={{ opacity: 1, x: 0 }}
                  className="flex items-center justify-between p-3 rounded-lg bg-white/[0.02] hover:bg-white/[0.04] transition-colors"
                >
                  <div className="flex items-center gap-3">
                    <div className={`w-9 h-9 rounded-lg bg-white/5 flex items-center justify-center ${config.color}`}>
                      <Icon className="w-4 h-4" />
                    </div>
                    <div>
                      <p className="text-sm font-medium text-[#fcfcfc]">{config.name}</p>
                      <div className="flex items-center gap-1.5">
                        {isConnected ? (
                          <>
                            <CheckCircle className="w-3 h-3 text-[#44f2d8]" />
                            <span className="text-[10px] font-mono text-[#44f2d8]">Connected</span>
                          </>
                        ) : (
                          <>
                            <XCircle className="w-3 h-3 text-[rgba(252,252,252,0.3)]" />
                            <span className="text-[10px] font-mono text-[rgba(252,252,252,0.3)]">Disconnected</span>
                          </>
                        )}
                      </div>
                    </div>
                  </div>

                  <div className="flex items-center gap-2">
                    {isConnected && connected && (
                      <>
                        <button
                          onClick={() => handleTest(connected.id)}
                          disabled={testingId === connected.id}
                          className="p-1.5 rounded text-[rgba(252,252,252,0.4)] hover:bg-white/5 hover:text-[#fcfcfc] transition-colors"
                          title="Test connection"
                        >
                          {testingId === connected.id ? (
                            <RefreshCw className="w-3.5 h-3.5 animate-spin" />
                          ) : (
                            <RefreshCw className="w-3.5 h-3.5" />
                          )}
                        </button>
                        <button
                          onClick={() => disconnect.mutate({ id: connected.id })}
                          className="px-3 py-1.5 rounded-lg text-xs font-mono text-[#ef4444] hover:bg-[#ef4444]/10 transition-colors border border-[#ef4444]/20"
                        >
                          Disconnect
                        </button>
                      </>
                    )}
                    {!isConnected && (
                      <button
                        onClick={() => connect.mutate({ platform: platformKey })}
                        className="px-3 py-1.5 rounded-lg text-xs font-mono text-[#44f2d8] hover:bg-[#44f2d8]/10 transition-colors border border-[#44f2d8]/20"
                      >
                        Connect
                      </button>
                    )}
                  </div>
                </motion.div>
              )
            })}
          </div>
        )}
      </div>

      {/* Security */}
      <div className="liquid-glass rounded-xl p-5">
        <h3 className="text-sm font-semibold text-[#fcfcfc] flex items-center gap-2 mb-4">
          <Shield className="w-4 h-4 text-[#818cf8]" />
          Security
        </h3>
        <div className="space-y-3">
          <div className="flex items-center justify-between p-3 rounded-lg bg-white/[0.02]">
            <div className="flex items-center gap-3">
              <KeyRound className="w-4 h-4 text-[rgba(252,252,252,0.4)]" />
              <div>
                <p className="text-sm text-[#fcfcfc]">API Key</p>
                <p className="text-[10px] font-mono text-[rgba(252,252,252,0.3)]">OpenAI integration key</p>
              </div>
            </div>
            <button className="px-3 py-1.5 rounded-lg text-xs font-mono text-[rgba(252,252,252,0.5)] hover:bg-white/5 transition-colors border border-white/10">
              Configure
            </button>
          </div>
          <div className="flex items-center justify-between p-3 rounded-lg bg-white/[0.02]">
            <div className="flex items-center gap-3">
              <Bell className="w-4 h-4 text-[rgba(252,252,252,0.4)]" />
              <div>
                <p className="text-sm text-[#fcfcfc]">Notifications</p>
                <p className="text-[10px] font-mono text-[rgba(252,252,252,0.3)]">Alert preferences</p>
              </div>
            </div>
            <div className="w-10 h-5 rounded-full bg-[#44f2d8]/20 relative cursor-pointer">
              <div className="absolute right-0.5 top-0.5 w-4 h-4 rounded-full bg-[#44f2d8]" />
            </div>
          </div>
        </div>
      </div>

      {/* System Info */}
      <div className="liquid-glass rounded-xl p-5">
        <h3 className="text-sm font-semibold text-[#fcfcfc] flex items-center gap-2 mb-4">
          <Database className="w-4 h-4 text-[rgba(252,252,252,0.4)]" />
          System Info
        </h3>
        <div className="grid grid-cols-2 gap-3">
          {[
            { label: 'Version', value: '2070.6.8-alpha' },
            { label: 'Neural Core', value: 'v4.2.1' },
            { label: 'Agents Framework', value: 'tRPC + Drizzle' },
            { label: 'Database', value: 'MySQL PlanetScale' },
            { label: 'Auth', value: 'OAuth 2.0 + JWT' },
            { label: 'Status', value: 'Autonomous' },
          ].map((info, i) => (
            <div key={i} className="p-3 rounded-lg bg-white/[0.02]">
              <p className="text-[10px] font-mono text-[rgba(252,252,252,0.3)] uppercase">{info.label}</p>
              <p className="text-xs font-mono text-[#44f2d8] mt-0.5">{info.value}</p>
            </div>
          ))}
        </div>
      </div>
    </div>
  )
}
