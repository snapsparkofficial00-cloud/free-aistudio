import { useState } from 'react'
import { motion } from 'framer-motion'
import {
  Brain,
  Lightbulb,
  Wrench,
  TrendingUp,
  MessageSquare,
  Zap,
  BarChart3,
  Loader2,
} from 'lucide-react'
import { trpc } from '@/providers/trpc'
import { AreaChart, Area, XAxis, YAxis, Tooltip, ResponsiveContainer } from 'recharts'

const TYPE_CONFIG: Record<string, { icon: any; color: string; bg: string }> = {
  learning: { icon: Lightbulb, color: 'text-yellow-400', bg: 'bg-yellow-400/10' },
  repair: { icon: Wrench, color: 'text-red-400', bg: 'bg-red-400/10' },
  upgrade: { icon: TrendingUp, color: 'text-green-400', bg: 'bg-green-400/10' },
  insight: { icon: Zap, color: 'text-[#44f2d8]', bg: 'bg-[#44f2d8]/10' },
  conversation: { icon: MessageSquare, color: 'text-[#818cf8]', bg: 'bg-[#818cf8]/10' },
}

export default function Memory() {
  const { data: insights, isLoading: insightsLoading } = trpc.memory.getInsights.useQuery()
  const { data: timeSeries } = trpc.analytics.timeSeries.useQuery({ metric: 'revenue', days: 30 })
  const { data: bySource } = trpc.analytics.bySource.useQuery()

  const [filter, setFilter] = useState<string>('all')

  const filteredMemory = filter === 'all'
    ? insights?.recent || []
    : (insights?.recent || []).filter(m => m.type === filter)

  const chartData = (timeSeries || []).map((t, i) => ({
    day: i + 1,
    value: t.value,
    date: t.date,
  }))

  return (
    <div className="space-y-6">
      {/* Header */}
      <div>
        <h1 className="text-2xl font-bold text-[#fcfcfc] flex items-center gap-3">
          <Brain className="w-6 h-6 text-[#44f2d8]" />
          Neural Memory
        </h1>
        <p className="text-sm font-mono text-[rgba(252,252,252,0.5)] mt-1">
          {insights?.total || 0} memories stored · {insights?.insights.length || 0} high-priority insights
        </p>
      </div>

      {/* Stats Row */}
      <div className="grid grid-cols-2 md:grid-cols-5 gap-3">
        {Object.entries(insights?.byType || {}).map(([type, count]) => {
          const config = TYPE_CONFIG[type]
          const Icon = config?.icon || Brain
          return (
            <motion.div
              key={type}
              initial={{ opacity: 0, scale: 0.9 }}
              animate={{ opacity: 1, scale: 1 }}
              whileHover={{ y: -2 }}
              onClick={() => setFilter(filter === type ? 'all' : type)}
              className={`liquid-glass rounded-xl p-4 cursor-pointer transition-all ${filter === type ? 'ring-1 ring-[#44f2d8]/30' : ''}`}
            >
              <Icon className={`w-5 h-5 ${config?.color} mb-2`} />
              <div className="text-xl font-bold text-[#fcfcfc]">{count}</div>
              <div className="text-[10px] font-mono text-[rgba(252,252,252,0.4)] capitalize">{type}</div>
            </motion.div>
          )
        })}
      </div>

      {/* Revenue Chart */}
      <div className="liquid-glass rounded-xl p-5">
        <h3 className="text-sm font-semibold text-[#fcfcfc] flex items-center gap-2 mb-4">
          <BarChart3 className="w-4 h-4 text-[#44f2d8]" />
          Revenue Trend (30 Days)
        </h3>
        <div className="h-48">
          <ResponsiveContainer width="100%" height="100%">
            <AreaChart data={chartData}>
              <defs>
                <linearGradient id="revenueGradient" x1="0" y1="0" x2="0" y2="1">
                  <stop offset="0%" stopColor="#44f2d8" stopOpacity={0.3} />
                  <stop offset="100%" stopColor="#44f2d8" stopOpacity={0} />
                </linearGradient>
              </defs>
              <XAxis dataKey="day" stroke="rgba(255,255,255,0.1)" tick={{ fill: 'rgba(252,252,252,0.3)', fontSize: 10, fontFamily: 'JetBrains Mono' }} />
              <YAxis stroke="rgba(255,255,255,0.1)" tick={{ fill: 'rgba(252,252,252,0.3)', fontSize: 10, fontFamily: 'JetBrains Mono' }} />
              <Tooltip
                contentStyle={{
                  background: 'rgba(20, 20, 25, 0.9)',
                  border: '1px solid rgba(255,255,255,0.1)',
                  borderRadius: 8,
                  fontSize: 12,
                  fontFamily: 'JetBrains Mono',
                  color: '#fcfcfc',
                }}
              />
              <Area type="monotone" dataKey="value" stroke="#44f2d8" fill="url(#revenueGradient)" strokeWidth={2} />
            </AreaChart>
          </ResponsiveContainer>
        </div>
      </div>

      {/* Source Breakdown */}
      <div className="liquid-glass rounded-xl p-5">
        <h3 className="text-sm font-semibold text-[#fcfcfc] mb-4">Earnings by Source</h3>
        <div className="space-y-3">
          {(bySource || []).map((source, i) => (
            <div key={i} className="flex items-center gap-3">
              <span className="text-xs font-mono text-[rgba(252,252,252,0.6)] w-32 truncate">{source.source}</span>
              <div className="flex-1 h-2 rounded-full bg-white/5 overflow-hidden">
                <motion.div
                  initial={{ width: 0 }}
                  animate={{ width: `${Math.min(100, (source.earnings / 100) * 100)}%` }}
                  transition={{ delay: 0.1 * i, duration: 0.6 }}
                  className="h-full rounded-full bg-gradient-accent"
                />
              </div>
              <span className="text-xs font-mono text-[#44f2d8] w-16 text-right">${source.earnings.toLocaleString()}</span>
            </div>
          ))}
        </div>
      </div>

      {/* Memory Feed */}
      <div className="space-y-3">
        <div className="flex items-center justify-between">
          <h3 className="text-sm font-semibold text-[#fcfcfc]">Memory Stream</h3>
          <div className="flex gap-1">
            {(['all', 'insight', 'learning', 'repair'] as const).map((f) => (
              <button
                key={f}
                onClick={() => setFilter(f === filter ? 'all' : f)}
                className={`px-2 py-1 rounded text-[10px] font-mono capitalize transition-all ${
                  filter === f ? 'bg-[#44f2d8]/10 text-[#44f2d8]' : 'text-[rgba(252,252,252,0.3)] hover:text-[rgba(252,252,252,0.6)]'
                }`}
              >
                {f}
              </button>
            ))}
          </div>
        </div>

        {insightsLoading ? (
          <div className="flex items-center justify-center h-32">
            <Loader2 className="w-6 h-6 text-[#44f2d8] animate-spin" />
          </div>
        ) : (
          filteredMemory.map((mem, i) => {
            const config = TYPE_CONFIG[mem.type]
            const Icon = config?.icon || Brain
            return (
              <motion.div
                key={mem.id}
                initial={{ opacity: 0, y: 10 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ delay: 0.03 * i }}
                className="liquid-glass rounded-xl p-4"
              >
                <div className="flex items-start gap-3">
                  <div className={`w-8 h-8 rounded-lg ${config?.bg} flex items-center justify-center flex-shrink-0`}>
                    <Icon className={`w-4 h-4 ${config?.color}`} />
                  </div>
                  <div className="flex-1">
                    <div className="flex items-center gap-2 mb-1">
                      <span className="text-[10px] font-mono px-1.5 py-0.5 rounded bg-white/5 text-[rgba(252,252,252,0.4)] capitalize">
                        {mem.type}
                      </span>
                      <span className="text-[10px] font-mono text-[rgba(252,252,252,0.3)]">
                        importance: {mem.importance}/10
                      </span>
                    </div>
                    <p className="text-xs text-[rgba(252,252,252,0.7)] leading-relaxed">{mem.content}</p>
                    {mem.tags && mem.tags.length > 0 && (
                      <div className="flex gap-1 mt-2 flex-wrap">
                        {mem.tags.map((tag, ti) => (
                          <span key={ti} className="text-[10px] font-mono px-1.5 py-0.5 rounded bg-[#44f2d8]/5 text-[#44f2d8]">
                            #{tag}
                          </span>
                        ))}
                      </div>
                    )}
                  </div>
                </div>
              </motion.div>
            )
          })
        )}
      </div>
    </div>
  )
}
