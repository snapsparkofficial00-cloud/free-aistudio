import { useRef, useState, useEffect } from 'react'
import { motion } from 'framer-motion'
import {
  Bot,
  TrendingUp,
  Cpu,
  Activity,
  Zap,
  Globe,
  Wallet,
  BarChart3,
  ArrowUpRight,
} from 'lucide-react'
import { trpc } from '@/providers/trpc'
import { GlitchWriter } from '@/components/effects/GlitchWriter'
import { CornerPulseBorder } from '@/components/effects/CornerPulseBorder'

// Tilt card component
function TiltCard({ children, className = '' }: { children: React.ReactNode; className?: string }) {
  const cardRef = useRef<HTMLDivElement>(null)
  const [style, setStyle] = useState({})
  const [glareStyle, setGlareStyle] = useState({})

  const handleMouseMove = (e: React.MouseEvent) => {
    const card = cardRef.current
    if (!card) return
    const rect = card.getBoundingClientRect()
    const percentX = (e.clientX - rect.left) / rect.width
    const percentY = (e.clientY - rect.top) / rect.height
    const rangeX = (percentX - 0.5) * 2
    const rangeY = (percentY - 0.5) * 2
    const intensity = 20

    setStyle({
      transform: `perspective(1000px) rotateX(${rangeY * -intensity}deg) rotateY(${rangeX * intensity}deg) scale3d(1.02, 1.02, 1.02)`,
      transition: 'transform 0.1s ease-out',
    })

    const glareOpacity = Math.min(1, Math.max(0, (Math.abs(rangeX) + Math.abs(rangeY)) * 0.3))
    setGlareStyle({
      background: `linear-gradient(${180 + rangeY * intensity * 2}deg, rgba(255,255,255,0) 0%, rgba(255,255,255,${glareOpacity}) ${percentY * 50}%, rgba(255,255,255,0) 100%)`,
    })
  }

  const handleMouseLeave = () => {
    setStyle({
      transform: 'perspective(1000px) rotateX(0deg) rotateY(0deg) scale3d(1, 1, 1)',
      transition: 'transform 0.5s ease-out',
    })
    setGlareStyle({ background: 'transparent' })
  }

  return (
    <div
      ref={cardRef}
      onMouseMove={handleMouseMove}
      onMouseLeave={handleMouseLeave}
      style={style}
      className={`relative overflow-hidden ${className}`}
    >
      {children}
      <div className="absolute inset-0 pointer-events-none rounded-xl" style={glareStyle} />
    </div>
  )
}

// Metric card
function MetricCard({ label, value, change, icon: Icon }: { label: string; value: string; change: string; icon: any }) {
  return (
    <motion.div
      initial={{ opacity: 0, y: 20 }}
      animate={{ opacity: 1, y: 0 }}
      whileHover={{ y: -2, boxShadow: '0 0 30px rgba(68, 242, 216, 0.2)' }}
      className="liquid-glass rounded-xl p-5 transition-shadow duration-300"
    >
      <div className="flex items-center justify-between mb-3">
        <span className="text-xs font-mono text-[rgba(252,252,252,0.5)] uppercase tracking-wider">{label}</span>
        <Icon className="w-4 h-4 text-[#44f2d8]" />
      </div>
      <div className="text-2xl font-bold text-[#fcfcfc] mb-1">{value}</div>
      <div className="flex items-center gap-1">
        <ArrowUpRight className="w-3 h-3 text-[#44f2d8]" />
        <span className="text-xs font-mono text-[#44f2d8]">{change}</span>
      </div>
    </motion.div>
  )
}

export default function Dashboard() {
  const { data: stats } = trpc.agent.getStats.useQuery()
  const { data: insights } = trpc.memory.getInsights.useQuery()
  const { data: commands } = trpc.command.list.useQuery()
  const { data: platforms } = trpc.platform.list.useQuery()

  const recentCommands = commands?.slice(0, 5) || []

  return (
    <div className="space-y-6">
      {/* Hero Core - Tilt Card */}
      <section className="flex justify-center" style={{ minHeight: '35vh' }}>
        <TiltCard className="w-full max-w-2xl">
          <div className="liquid-glass rounded-xl p-8 text-center relative overflow-hidden">
            <div className="absolute inset-0 bg-gradient-radial from-[#818cf8]/10 via-transparent to-transparent" />
            <div className="relative z-10">
              <motion.div
                initial={{ opacity: 0, y: 10 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ delay: 0.2 }}
              >
                <div className="flex items-center justify-center gap-2 mb-4">
                  <div className="status-dot active" />
                  <span className="text-xs font-mono text-[#44f2d8] tracking-[0.3em]">SYSTEM STATUS</span>
                </div>
                <h1 className="text-3xl md:text-4xl font-bold tracking-tight text-[#fcfcfc] mb-3">
                  AUTONOMOUS REVENUE STREAM
                </h1>
                <p className="text-lg text-gradient font-semibold mb-2">ACTIVE</p>
                <p className="text-sm text-[rgba(252,252,252,0.6)] max-w-md mx-auto">
                  Multi-agent consensus reached. Yield farming sequence initiated.
                  {stats?.active || 0} agents coordinating {stats?.totalTasks || 0} tasks.
                </p>
              </motion.div>
            </div>
          </div>
        </TiltCard>
      </section>

      {/* Terminal Command Strip */}
      <section className="bg-[#050505] border-y border-white/5 py-3 px-4">
        <GlitchWriter />
      </section>

      {/* Metrics Row */}
      <section className="grid grid-cols-2 md:grid-cols-4 gap-4">
        <MetricCard
          label="Total Earnings"
          value={`$${(stats?.totalEarnings || 0).toLocaleString()}`}
          change="+12.4%"
          icon={Wallet}
        />
        <MetricCard
          label="Active Agents"
          value={String(stats?.active || 0)}
          change={`${stats?.paused || 0} paused`}
          icon={Bot}
        />
        <MetricCard
          label="Tasks Completed"
          value={String(stats?.totalTasks || 0)}
          change="+8.2%"
          icon={Cpu}
        />
        <MetricCard
          label="System Uptime"
          value="99.9%"
          change="0.004s latency"
          icon={Activity}
        />
      </section>

      {/* Bento Grid */}
      <section className="grid grid-cols-1 lg:grid-cols-12 gap-4">
        {/* Active Agents - Large */}
        <motion.div
          initial={{ opacity: 0, x: -20 }}
          animate={{ opacity: 1, x: 0 }}
          transition={{ delay: 0.1 }}
          className="lg:col-span-8"
        >
          <CornerPulseBorder className="rounded-xl">
            <div className="liquid-glass rounded-xl p-5 h-full">
              <div className="flex items-center justify-between mb-4">
                <h3 className="text-sm font-semibold text-[#fcfcfc] flex items-center gap-2">
                  <Zap className="w-4 h-4 text-[#44f2d8]" />
                  Active Agents
                </h3>
                <span className="text-xs font-mono text-[rgba(252,252,252,0.4)]">
                  {stats?.active || 0}/{stats?.total || 0} online
                </span>
              </div>
              <div className="space-y-2">
                {recentCommands.map((cmd, i) => (
                  <motion.div
                    key={i}
                    initial={{ opacity: 0, x: -10 }}
                    animate={{ opacity: 1, x: 0 }}
                    transition={{ delay: 0.1 * i }}
                    className="flex items-center gap-3 p-3 rounded-lg bg-white/[0.02] hover:bg-white/[0.04] transition-colors"
                  >
                    <div className="status-dot active" />
                    <div className="flex-1 min-w-0">
                      <p className="text-xs font-mono text-[#fcfcfc] truncate">{cmd.executedBy}</p>
                      <p className="text-[10px] font-mono text-[rgba(252,252,252,0.4)] truncate">{cmd.text}</p>
                    </div>
                    <span className="text-[10px] font-mono text-[#44f2d8]">{cmd.status}</span>
                  </motion.div>
                ))}
              </div>
            </div>
          </CornerPulseBorder>
        </motion.div>

        {/* Capital Flow */}
        <motion.div
          initial={{ opacity: 0, x: 20 }}
          animate={{ opacity: 1, x: 0 }}
          transition={{ delay: 0.2 }}
          className="lg:col-span-4"
        >
          <div className="liquid-glass rounded-xl p-5 h-full">
            <h3 className="text-sm font-semibold text-[#fcfcfc] flex items-center gap-2 mb-4">
              <TrendingUp className="w-4 h-4 text-[#818cf8]" />
              Capital Flow
            </h3>
            <div className="space-y-3">
              {(platforms || []).map((platform, i) => (
                <div key={i} className="space-y-1">
                  <div className="flex justify-between text-xs">
                    <span className="font-mono text-[rgba(252,252,252,0.6)] capitalize">{platform.platform}</span>
                    <span className={`font-mono ${platform.status === 'connected' ? 'text-[#44f2d8]' : 'text-[rgba(252,252,252,0.3)]'}`}>
                      {platform.status}
                    </span>
                  </div>
                  <div className="h-1.5 rounded-full bg-white/5 overflow-hidden">
                    <motion.div
                      initial={{ width: 0 }}
                      animate={{ width: platform.status === 'connected' ? `${60 + Math.random() * 40}%` : '0%' }}
                      transition={{ delay: 0.3 + i * 0.1, duration: 0.8 }}
                      className="h-full rounded-full bg-gradient-accent"
                    />
                  </div>
                </div>
              ))}
            </div>
          </div>
        </motion.div>

        {/* Self-Learning Matrix */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.3 }}
          className="lg:col-span-4"
        >
          <div className="liquid-glass rounded-xl p-5 h-full">
            <h3 className="text-sm font-semibold text-[#fcfcfc] flex items-center gap-2 mb-4">
              <BarChart3 className="w-4 h-4 text-[#818cf8]" />
              Self-Learning Matrix
            </h3>
            <div className="space-y-2 max-h-48 overflow-y-auto scrollbar-thin">
              {(insights?.insights || []).slice(0, 5).map((insight, i) => (
                <div key={i} className="p-2.5 rounded-lg bg-white/[0.02]">
                  <div className="flex items-center gap-2 mb-1">
                    <span className="text-[10px] font-mono px-1.5 py-0.5 rounded bg-[#44f2d8]/10 text-[#44f2d8]">
                      {insight.type}
                    </span>
                    <span className="text-[10px] font-mono text-[rgba(252,252,252,0.3)]">
                      importance: {insight.importance}/10
                    </span>
                  </div>
                  <p className="text-[10px] font-mono text-[rgba(252,252,252,0.5)] line-clamp-2">
                    {insight.content}
                  </p>
                </div>
              ))}
            </div>
          </div>
        </motion.div>

        {/* Performance Metrics */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.4 }}
          className="lg:col-span-8"
        >
          <div className="liquid-glass rounded-xl p-5 h-full">
            <h3 className="text-sm font-semibold text-[#fcfcfc] flex items-center gap-2 mb-4">
              <Globe className="w-4 h-4 text-[#44f2d8]" />
              Performance Metrics
            </h3>
            <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
              {[
                { label: 'Efficiency', value: '+94.7%', sub: 'vs last week' },
                { label: 'Latency', value: '0.004s', sub: 'avg response' },
                { label: 'Memory', value: '62%', sub: 'utilization' },
                { label: 'Neural Sync', value: '100%', sub: 'all agents' },
              ].map((metric, i) => (
                <motion.div
                  key={i}
                  initial={{ opacity: 0, scale: 0.9 }}
                  animate={{ opacity: 1, scale: 1 }}
                  transition={{ delay: 0.5 + i * 0.1 }}
                  className="text-center p-4 rounded-lg bg-white/[0.02]"
                >
                  <div className="text-2xl font-bold text-gradient mb-1">{metric.value}</div>
                  <div className="text-xs font-mono text-[rgba(252,252,252,0.5)]">{metric.label}</div>
                  <div className="text-[10px] font-mono text-[rgba(252,252,252,0.3)]">{metric.sub}</div>
                </motion.div>
              ))}
            </div>
          </div>
        </motion.div>
      </section>
    </div>
  )
}
