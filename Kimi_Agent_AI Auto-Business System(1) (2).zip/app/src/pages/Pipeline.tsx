import { useState } from 'react'
import { motion, AnimatePresence } from 'framer-motion'
import {
  GitBranch,
  Plus,
  Sparkles,
  Eye,
  Send,
  Trash2,
  Youtube,
  Facebook,
  Globe,
  Smartphone,
  Loader2,
  CheckCircle,
  Clock,
  FileText,
} from 'lucide-react'
import { trpc } from '@/providers/trpc'

const TYPE_CONFIG: Record<string, { icon: any; color: string; label: string }> = {
  youtube: { icon: Youtube, color: 'text-red-400', label: 'YouTube' },
  facebook: { icon: Facebook, color: 'text-blue-400', label: 'Facebook' },
  website: { icon: Globe, color: 'text-green-400', label: 'Website' },
  app: { icon: Smartphone, color: 'text-purple-400', label: 'App' },
}

const STATUS_STEPS = ['draft', 'generating', 'review', 'scheduled', 'published'] as const

export default function Pipeline() {
  const utils = trpc.useUtils()
  const { data: items, isLoading } = trpc.content.list.useQuery()
  const createItem = trpc.content.create.useMutation({ onSuccess: () => utils.content.list.invalidate() })
  const generateItem = trpc.content.generate.useMutation({ onSuccess: () => utils.content.list.invalidate() })
  const publishItem = trpc.content.publish.useMutation({ onSuccess: () => utils.content.list.invalidate() })
  const deleteItem = trpc.content.delete.useMutation({ onSuccess: () => utils.content.list.invalidate() })

  const [showCreate, setShowCreate] = useState(false)
  const [newItem, setNewItem] = useState({ title: '', type: 'youtube' as const })
  const [expandedItem, setExpandedItem] = useState<number | null>(null)

  const handleCreate = () => {
    if (!newItem.title.trim()) return
    createItem.mutate(newItem)
    setShowCreate(false)
    setNewItem({ title: '', type: 'youtube' })
  }

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-2xl font-bold text-[#fcfcfc] flex items-center gap-3">
            <GitBranch className="w-6 h-6 text-[#44f2d8]" />
            Content Pipeline
          </h1>
          <p className="text-sm font-mono text-[rgba(252,252,252,0.5)] mt-1">
            {items?.length || 0} items · {items?.filter(i => i.status === 'published').length || 0} published
          </p>
        </div>
        <button
          onClick={() => setShowCreate(true)}
          className="flex items-center gap-2 px-4 py-2 rounded-lg bg-gradient-accent text-[#0a0a0a] text-sm font-semibold hover:shadow-glow-lg transition-shadow"
        >
          <Plus className="w-4 h-4" />
          New Content
        </button>
      </div>

      {/* Pipeline Flow */}
      <div className="flex items-center gap-2 overflow-x-auto pb-2">
        {STATUS_STEPS.map((step, i) => {
          const count = items?.filter(item => item.status === step).length || 0
          return (
            <div key={step} className="flex items-center gap-2 flex-shrink-0">
              <div className={`px-3 py-1.5 rounded-full text-xs font-mono capitalize border ${
                count > 0 ? 'border-[#44f2d8]/30 text-[#44f2d8] bg-[#44f2d8]/5' : 'border-white/5 text-[rgba(252,252,252,0.3)]'
              }`}>
                {step} ({count})
              </div>
              {i < STATUS_STEPS.length - 1 && (
                <div className="w-6 h-px bg-white/10" />
              )}
            </div>
          )
        })}
      </div>

      {/* Create Modal */}
      <AnimatePresence>
        {showCreate && (
          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            className="fixed inset-0 z-50 flex items-center justify-center bg-black/60 backdrop-blur-sm"
            onClick={() => setShowCreate(false)}
          >
            <motion.div
              initial={{ scale: 0.9 }}
              animate={{ scale: 1 }}
              exit={{ scale: 0.9 }}
              onClick={(e) => e.stopPropagation()}
              className="liquid-glass-strong rounded-xl p-6 w-full max-w-md border border-white/10"
            >
              <h2 className="text-lg font-bold text-[#fcfcfc] mb-4">Create Content</h2>
              <div className="space-y-4">
                <div>
                  <label className="text-xs font-mono text-[rgba(252,252,252,0.5)] block mb-1">Title</label>
                  <input
                    value={newItem.title}
                    onChange={(e) => setNewItem({ ...newItem, title: e.target.value })}
                    className="w-full px-3 py-2 rounded-lg bg-white/5 border border-white/10 text-sm text-[#fcfcfc] focus:outline-none focus:border-[#44f2d8]/50"
                    placeholder="Content title..."
                  />
                </div>
                <div>
                  <label className="text-xs font-mono text-[rgba(252,252,252,0.5)] block mb-1">Type</label>
                  <div className="grid grid-cols-4 gap-2">
                    {(['youtube', 'facebook', 'website', 'app'] as const).map((type) => {
                      const config = TYPE_CONFIG[type]
                      const Icon = config.icon
                      return (
                        <button
                          key={type}
                          onClick={() => setNewItem({ ...newItem, type })}
                          className={`p-3 rounded-lg border text-center transition-all ${
                            newItem.type === type
                              ? 'border-[#44f2d8]/30 bg-[#44f2d8]/5'
                              : 'border-white/5 hover:border-white/10'
                          }`}
                        >
                          <Icon className={`w-5 h-5 mx-auto mb-1 ${config.color}`} />
                          <span className="text-[10px] font-mono text-[rgba(252,252,252,0.6)]">{config.label}</span>
                        </button>
                      )
                    })}
                  </div>
                </div>
                <div className="flex gap-2 pt-2">
                  <button
                    onClick={handleCreate}
                    className="flex-1 py-2 rounded-lg bg-gradient-accent text-[#0a0a0a] text-sm font-semibold hover:shadow-glow transition-shadow"
                  >
                    Create
                  </button>
                  <button
                    onClick={() => setShowCreate(false)}
                    className="px-4 py-2 rounded-lg bg-white/5 text-sm text-[rgba(252,252,252,0.6)] hover:bg-white/10"
                  >
                    Cancel
                  </button>
                </div>
              </div>
            </motion.div>
          </motion.div>
        )}
      </AnimatePresence>

      {/* Content Grid */}
      {isLoading ? (
        <div className="flex items-center justify-center h-32">
          <Loader2 className="w-6 h-6 text-[#44f2d8] animate-spin" />
        </div>
      ) : (
        <div className="space-y-3">
          <AnimatePresence>
            {(items || []).map((item, i) => {
              const config = TYPE_CONFIG[item.type]
              const Icon = config?.icon || FileText
              const isExpanded = expandedItem === item.id

              return (
                <motion.div
                  key={item.id}
                  initial={{ opacity: 0, y: 10 }}
                  animate={{ opacity: 1, y: 0 }}
                  exit={{ opacity: 0 }}
                  transition={{ delay: i * 0.03 }}
                  className="liquid-glass rounded-xl overflow-hidden"
                >
                  <div
                    className="p-4 flex items-center gap-4 cursor-pointer hover:bg-white/[0.02] transition-colors"
                    onClick={() => setExpandedItem(isExpanded ? null : item.id)}
                  >
                    <div className={`w-10 h-10 rounded-lg bg-white/5 flex items-center justify-center ${config?.color || ''}`}>
                      <Icon className="w-5 h-5" />
                    </div>
                    <div className="flex-1 min-w-0">
                      <h3 className="text-sm font-semibold text-[#fcfcfc] truncate">{item.title}</h3>
                      <div className="flex items-center gap-2 mt-0.5">
                        <span className="text-[10px] font-mono px-1.5 py-0.5 rounded bg-white/5 text-[rgba(252,252,252,0.4)] capitalize">
                          {item.type}
                        </span>
                        <span className={`text-[10px] font-mono px-1.5 py-0.5 rounded capitalize ${
                          item.status === 'published' ? 'bg-[#44f2d8]/10 text-[#44f2d8]' :
                          item.status === 'generating' ? 'bg-[#818cf8]/10 text-[#818cf8]' :
                          'bg-white/5 text-[rgba(252,252,252,0.4)]'
                        }`}>
                          {item.status}
                        </span>
                        {item.earnings && Number(item.earnings) > 0 && (
                          <span className="text-[10px] font-mono text-[#44f2d8]">
                            ${Number(item.earnings).toLocaleString()}
                          </span>
                        )}
                      </div>
                    </div>

                    {/* Progress bar */}
                    <div className="hidden sm:flex items-center gap-1">
                      {STATUS_STEPS.map((step, si) => (
                        <div
                          key={step}
                          className={`w-2 h-2 rounded-full ${
                            si <= STATUS_STEPS.indexOf(item.status as any)
                              ? 'bg-[#44f2d8]'
                              : 'bg-white/10'
                          }`}
                        />
                      ))}
                    </div>

                    {/* Actions */}
                    <div className="flex items-center gap-1">
                      {item.status === 'draft' && (
                        <button
                          onClick={(e) => { e.stopPropagation(); generateItem.mutate({ id: item.id }); }}
                          className="p-1.5 rounded text-[#818cf8] hover:bg-[#818cf8]/10 transition-colors"
                          title="Generate content"
                        >
                          <Sparkles className="w-3.5 h-3.5" />
                        </button>
                      )}
                      {item.status === 'review' && (
                        <button
                          onClick={(e) => { e.stopPropagation(); publishItem.mutate({ id: item.id }); }}
                          className="p-1.5 rounded text-[#44f2d8] hover:bg-[#44f2d8]/10 transition-colors"
                          title="Publish"
                        >
                          <Send className="w-3.5 h-3.5" />
                        </button>
                      )}
                      <button
                        onClick={(e) => { e.stopPropagation(); deleteItem.mutate({ id: item.id }); }}
                        className="p-1.5 rounded text-[rgba(252,252,252,0.3)] hover:bg-[#ef4444]/10 hover:text-[#ef4444] transition-colors"
                      >
                        <Trash2 className="w-3.5 h-3.5" />
                      </button>
                    </div>
                  </div>

                  {/* Expanded content */}
                  <AnimatePresence>
                    {isExpanded && item.content && (
                      <motion.div
                        initial={{ height: 0, opacity: 0 }}
                        animate={{ height: 'auto', opacity: 1 }}
                        exit={{ height: 0, opacity: 0 }}
                        className="overflow-hidden"
                      >
                        <div className="px-4 pb-4">
                          <div className="p-4 rounded-lg bg-[#050505] border border-white/5 font-mono text-xs text-[rgba(252,252,252,0.6)] whitespace-pre-wrap leading-relaxed max-h-64 overflow-y-auto scrollbar-thin">
                            {item.content}
                          </div>
                        </div>
                      </motion.div>
                    )}
                  </AnimatePresence>
                </motion.div>
              )
            })}
          </AnimatePresence>
        </div>
      )}
    </div>
  )
}
