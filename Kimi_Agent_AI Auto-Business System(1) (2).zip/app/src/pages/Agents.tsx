import { useState } from 'react'
import { motion, AnimatePresence } from 'framer-motion'
import {
  Bot,
  Play,
  Pause,
  Trash2,
  Plus,
  Youtube,
  Facebook,
  Globe,
  Smartphone,
  TrendingUp,
  Wrench,
  Sparkles,
} from 'lucide-react'
import { trpc } from '@/providers/trpc'

const TYPE_ICONS: Record<string, any> = {
  youtube: Youtube,
  facebook: Facebook,
  website: Globe,
  app: Smartphone,
  trading: TrendingUp,
  custom: Wrench,
}

const TYPE_COLORS: Record<string, string> = {
  youtube: 'text-red-400',
  facebook: 'text-blue-400',
  website: 'text-green-400',
  app: 'text-purple-400',
  trading: 'text-yellow-400',
  custom: 'text-gray-400',
}

export default function Agents() {
  const utils = trpc.useUtils()
  const { data: agents, isLoading } = trpc.agent.list.useQuery()
  const { data: stats } = trpc.agent.getStats.useQuery()
  const toggleStatus = trpc.agent.toggleStatus.useMutation({ onSuccess: () => utils.agent.list.invalidate() })
  const deleteAgent = trpc.agent.delete.useMutation({ onSuccess: () => { utils.agent.list.invalidate(); utils.agent.getStats.invalidate(); } })
  const createAgent = trpc.agent.create.useMutation({ onSuccess: () => { utils.agent.list.invalidate(); utils.agent.getStats.invalidate(); } })

  const [showCreate, setShowCreate] = useState(false)
  const [newAgent, setNewAgent] = useState({ name: '', type: 'custom' as const, description: '' })

  const handleCreate = () => {
    if (!newAgent.name.trim()) return
    createAgent.mutate(newAgent)
    setShowCreate(false)
    setNewAgent({ name: '', type: 'custom', description: '' })
  }

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-2xl font-bold text-[#fcfcfc] flex items-center gap-3">
            <Bot className="w-6 h-6 text-[#44f2d8]" />
            AI Agents
          </h1>
          <p className="text-sm font-mono text-[rgba(252,252,252,0.5)] mt-1">
            {stats?.total || 0} agents · {stats?.active || 0} active · ${(stats?.totalEarnings || 0).toLocaleString()} earned
          </p>
        </div>
        <button
          onClick={() => setShowCreate(true)}
          className="flex items-center gap-2 px-4 py-2 rounded-lg bg-gradient-accent text-[#0a0a0a] text-sm font-semibold hover:shadow-glow-lg transition-shadow"
        >
          <Plus className="w-4 h-4" />
          Deploy Agent
        </button>
      </div>

      {/* Status Filters */}
      <div className="flex gap-2">
        {(['all', 'active', 'paused', 'learning', 'error'] as const).map((status) => (
          <button
            key={status}
            className={`px-3 py-1.5 rounded-full text-xs font-mono capitalize transition-all ${
              status === 'all'
                ? 'bg-[#44f2d8]/10 text-[#44f2d8] border border-[#44f2d8]/20'
                : 'text-[rgba(252,252,252,0.4)] hover:text-[#fcfcfc] hover:bg-white/5'
            }`}
          >
            {status === 'all' ? 'All' : `${status} (${stats?.[status] || 0})`}
          </button>
        ))}
      </div>

      {/* Create Modal */}
      <AnimatePresence>
        {showCreate && (
          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            className="fixed inset-0 z-50 flex items-center justify-center bg-black/60 backdrop-blur-sm"
            onClick={() => setShowCreate(false)}
          >
            <motion.div
              initial={{ scale: 0.9, opacity: 0 }}
              animate={{ scale: 1, opacity: 1 }}
              exit={{ scale: 0.9, opacity: 0 }}
              onClick={(e) => e.stopPropagation()}
              className="liquid-glass-strong rounded-xl p-6 w-full max-w-md border border-white/10"
            >
              <h2 className="text-lg font-bold text-[#fcfcfc] mb-4 flex items-center gap-2">
                <Sparkles className="w-5 h-5 text-[#44f2d8]" />
                Deploy New Agent
              </h2>
              <div className="space-y-4">
                <div>
                  <label className="text-xs font-mono text-[rgba(252,252,252,0.5)] block mb-1">Agent Name</label>
                  <input
                    value={newAgent.name}
                    onChange={(e) => setNewAgent({ ...newAgent, name: e.target.value })}
                    className="w-full px-3 py-2 rounded-lg bg-white/5 border border-white/10 text-sm text-[#fcfcfc] focus:outline-none focus:border-[#44f2d8]/50"
                    placeholder="e.g. Content Generator"
                  />
                </div>
                <div>
                  <label className="text-xs font-mono text-[rgba(252,252,252,0.5)] block mb-1">Type</label>
                  <select
                    value={newAgent.type}
                    onChange={(e) => setNewAgent({ ...newAgent, type: e.target.value as any })}
                    className="w-full px-3 py-2 rounded-lg bg-white/5 border border-white/10 text-sm text-[#fcfcfc] focus:outline-none focus:border-[#44f2d8]/50"
                  >
                    <option value="youtube">YouTube</option>
                    <option value="facebook">Facebook</option>
                    <option value="website">Website</option>
                    <option value="app">App</option>
                    <option value="trading">Trading</option>
                    <option value="custom">Custom</option>
                  </select>
                </div>
                <div>
                  <label className="text-xs font-mono text-[rgba(252,252,252,0.5)] block mb-1">Description</label>
                  <textarea
                    value={newAgent.description}
                    onChange={(e) => setNewAgent({ ...newAgent, description: e.target.value })}
                    className="w-full px-3 py-2 rounded-lg bg-white/5 border border-white/10 text-sm text-[#fcfcfc] focus:outline-none focus:border-[#44f2d8]/50 h-20 resize-none"
                    placeholder="What does this agent do?"
                  />
                </div>
                <div className="flex gap-2 pt-2">
                  <button
                    onClick={handleCreate}
                    className="flex-1 py-2 rounded-lg bg-gradient-accent text-[#0a0a0a] text-sm font-semibold hover:shadow-glow transition-shadow"
                  >
                    Deploy
                  </button>
                  <button
                    onClick={() => setShowCreate(false)}
                    className="px-4 py-2 rounded-lg bg-white/5 text-sm text-[rgba(252,252,252,0.6)] hover:bg-white/10 transition-colors"
                  >
                    Cancel
                  </button>
                </div>
              </div>
            </motion.div>
          </motion.div>
        )}
      </AnimatePresence>

      {/* Agent Grid */}
      {isLoading ? (
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
          {[1, 2, 3].map((i) => (
            <div key={i} className="liquid-glass rounded-xl p-5 animate-pulse">
              <div className="h-4 bg-white/5 rounded w-1/2 mb-3" />
              <div className="h-3 bg-white/5 rounded w-3/4 mb-2" />
              <div className="h-3 bg-white/5 rounded w-1/2" />
            </div>
          ))}
        </div>
      ) : (
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
          <AnimatePresence>
            {(agents || []).map((agent, i) => {
              const Icon = TYPE_ICONS[agent.type] || Bot
              return (
                <motion.div
                  key={agent.id}
                  initial={{ opacity: 0, y: 20 }}
                  animate={{ opacity: 1, y: 0 }}
                  exit={{ opacity: 0, scale: 0.9 }}
                  transition={{ delay: i * 0.05 }}
                  whileHover={{ y: -2, boxShadow: '0 0 30px rgba(68, 242, 216, 0.15)' }}
                  className="liquid-glass rounded-xl p-5 transition-all duration-300"
                >
                  <div className="flex items-start justify-between mb-3">
                    <div className="flex items-center gap-3">
                      <div className={`w-9 h-9 rounded-lg bg-white/5 flex items-center justify-center ${TYPE_COLORS[agent.type]}`}>
                        <Icon className="w-4 h-4" />
                      </div>
                      <div>
                        <h3 className="text-sm font-semibold text-[#fcfcfc]">{agent.name}</h3>
                        <span className="text-[10px] font-mono text-[rgba(252,252,252,0.4)] capitalize">{agent.type}</span>
                      </div>
                    </div>
                    <div className={`status-dot ${agent.status}`} />
                  </div>

                  <p className="text-xs text-[rgba(252,252,252,0.5)] mb-4 line-clamp-2">{agent.description}</p>

                  <div className="flex items-center justify-between text-xs font-mono">
                    <span className="text-[#44f2d8]">${Number(agent.earnings).toLocaleString()}</span>
                    <span className="text-[rgba(252,252,252,0.4)]">{agent.tasksCompleted} tasks</span>
                  </div>

                  <div className="flex gap-1 mt-3 pt-3 border-t border-white/5">
                    <button
                      onClick={() => toggleStatus.mutate({ id: agent.id })}
                      className="flex-1 flex items-center justify-center gap-1 py-1.5 rounded text-xs font-mono text-[rgba(252,252,252,0.5)] hover:bg-white/5 hover:text-[#fcfcfc] transition-colors"
                    >
                      {agent.status === 'active' ? <Pause className="w-3 h-3" /> : <Play className="w-3 h-3" />}
                      {agent.status === 'active' ? 'Pause' : 'Activate'}
                    </button>
                    <button
                      onClick={() => deleteAgent.mutate({ id: agent.id })}
                      className="px-2 py-1.5 rounded text-xs text-[rgba(252,252,252,0.3)] hover:bg-[#ef4444]/10 hover:text-[#ef4444] transition-colors"
                    >
                      <Trash2 className="w-3 h-3" />
                    </button>
                  </div>
                </motion.div>
              )
            })}
          </AnimatePresence>
        </div>
      )}
    </div>
  )
}
