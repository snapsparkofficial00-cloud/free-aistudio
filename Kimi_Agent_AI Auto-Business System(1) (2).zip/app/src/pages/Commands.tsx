import { useState, useRef, useEffect } from 'react'
import { motion, AnimatePresence } from 'framer-motion'
import { Terminal, Send, Clock, CheckCircle, AlertCircle, Loader2 } from 'lucide-react'
import { trpc } from '@/providers/trpc'

export default function Commands() {
  const utils = trpc.useUtils()
  const { data: commands, isLoading } = trpc.command.list.useQuery()
  const submitCmd = trpc.command.submit.useMutation({
    onSuccess: () => {
      utils.command.list.invalidate()
      setInput('')
      setIsProcessing(false)
    },
  })

  const [input, setInput] = useState('')
  const [isProcessing, setIsProcessing] = useState(false)
  const scrollRef = useRef<HTMLDivElement>(null)

  useEffect(() => {
    if (scrollRef.current) {
      scrollRef.current.scrollTop = scrollRef.current.scrollHeight
    }
  }, [commands])

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault()
    if (!input.trim() || isProcessing) return
    setIsProcessing(true)
    submitCmd.mutate({ text: input.trim() })
  }

  const statusIcon = (status: string) => {
    switch (status) {
      case 'completed': return <CheckCircle className="w-3.5 h-3.5 text-[#44f2d8]" />
      case 'processing': return <Loader2 className="w-3.5 h-3.5 text-[#818cf8] animate-spin" />
      case 'failed': return <AlertCircle className="w-3.5 h-3.5 text-[#ef4444]" />
      default: return <Clock className="w-3.5 h-3.5 text-[rgba(252,252,252,0.3)]" />
    }
  }

  return (
    <div className="space-y-6 h-[calc(100vh-120px)] flex flex-col">
      {/* Header */}
      <div>
        <h1 className="text-2xl font-bold text-[#fcfcfc] flex items-center gap-3">
          <Terminal className="w-6 h-6 text-[#44f2d8]" />
          Command Center
        </h1>
        <p className="text-sm font-mono text-[rgba(252,252,252,0.5)] mt-1">
          Natural language interface to control your AI agents
        </p>
      </div>

      {/* Command History */}
      <div
        ref={scrollRef}
        className="flex-1 overflow-y-auto scrollbar-thin space-y-3 pr-2"
      >
        {isLoading ? (
          <div className="flex items-center justify-center h-32">
            <Loader2 className="w-6 h-6 text-[#44f2d8] animate-spin" />
          </div>
        ) : (
          <AnimatePresence>
            {(commands || []).map((cmd, i) => (
              <motion.div
                key={i}
                initial={{ opacity: 0, y: 10 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ delay: 0.02 * i }}
                className="liquid-glass rounded-xl p-4"
              >
                {/* User Command */}
                <div className="flex items-start gap-3 mb-3">
                  <div className="w-6 h-6 rounded-full bg-gradient-accent flex items-center justify-center text-[10px] font-bold text-[#0a0a0a] flex-shrink-0 mt-0.5">
                    U
                  </div>
                  <div className="flex-1">
                    <p className="text-sm text-[#fcfcfc]">{cmd.text}</p>
                    <span className="text-[10px] font-mono text-[rgba(252,252,252,0.3)]">
                      {new Date(cmd.createdAt).toLocaleTimeString()}
                    </span>
                  </div>
                </div>

                {/* System Response */}
                {cmd.response && (
                  <div className="flex items-start gap-3 pl-9">
                    <div className="flex-1 p-3 rounded-lg bg-[#44f2d8]/5 border border-[#44f2d8]/10">
                      <div className="flex items-center gap-2 mb-2">
                        {statusIcon(cmd.status)}
                        <span className="text-[10px] font-mono text-[#44f2d8]">{cmd.executedBy}</span>
                      </div>
                      <p className="text-xs text-[rgba(252,252,252,0.7)] leading-relaxed">{cmd.response}</p>
                    </div>
                  </div>
                )}
              </motion.div>
            ))}
          </AnimatePresence>
        )}

        {/* Processing indicator */}
        {isProcessing && (
          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            className="liquid-glass rounded-xl p-4 flex items-center gap-3"
          >
            <Loader2 className="w-4 h-4 text-[#818cf8] animate-spin" />
            <span className="text-xs font-mono text-[rgba(252,252,252,0.5)]">
              Neural consensus engine processing...
            </span>
          </motion.div>
        )}
      </div>

      {/* Input */}
      <form onSubmit={handleSubmit} className="relative">
        <div className="liquid-glass rounded-xl flex items-center gap-3 p-2 border border-[#44f2d8]/20 focus-within:border-[#44f2d8]/40 transition-colors">
          <Terminal className="w-4 h-4 text-[#44f2d8] ml-2 flex-shrink-0" />
          <input
            value={input}
            onChange={(e) => setInput(e.target.value)}
            placeholder="Enter command: e.g. 'Create YouTube video about AI trends'..."
            className="flex-1 bg-transparent text-sm text-[#fcfcfc] placeholder:text-[rgba(252,252,252,0.3)] focus:outline-none py-2"
            disabled={isProcessing}
          />
          <button
            type="submit"
            disabled={isProcessing || !input.trim()}
            className="px-4 py-2 rounded-lg bg-gradient-accent text-[#0a0a0a] text-sm font-semibold hover:shadow-glow transition-shadow disabled:opacity-50 disabled:cursor-not-allowed flex items-center gap-1"
          >
            <Send className="w-3.5 h-3.5" />
            Execute
          </button>
        </div>
        <p className="text-[10px] font-mono text-[rgba(252,252,252,0.3)] mt-2 px-1">
          Try: "Create YouTube video", "Generate Facebook Reels", "Build website", "Show revenue strategies", "Repair system"
        </p>
      </form>
    </div>
  )
}
