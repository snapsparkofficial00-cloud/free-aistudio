import {
  mysqlTable,
  mysqlEnum,
  serial,
  varchar,
  text,
  timestamp,
  json,
  decimal,
  int,
  date,
  bigint,
} from "drizzle-orm/mysql-core";

export const users = mysqlTable("users", {
  id: serial("id").primaryKey(),
  unionId: varchar("unionId", { length: 255 }).notNull().unique(),
  name: varchar("name", { length: 255 }),
  email: varchar("email", { length: 320 }),
  avatar: text("avatar"),
  role: mysqlEnum("role", ["user", "admin"]).default("user").notNull(),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
  updatedAt: timestamp("updatedAt")
    .defaultNow()
    .notNull()
    .$onUpdate(() => new Date()),
  lastSignInAt: timestamp("lastSignInAt").defaultNow().notNull(),
});

export type User = typeof users.$inferSelect;
export type InsertUser = typeof users.$inferInsert;

export const agents = mysqlTable("agents", {
  id: serial("id").primaryKey(),
  userId: bigint("userId", { mode: "number", unsigned: true }).notNull(),
  name: varchar("name", { length: 255 }).notNull(),
  type: mysqlEnum("type", ["youtube", "facebook", "website", "app", "trading", "custom"]).notNull(),
  status: mysqlEnum("status", ["active", "paused", "error", "learning"]).default("paused").notNull(),
  description: text("description"),
  config: json("config").$type<Record<string, any>>(),
  earnings: decimal("earnings", { precision: 12, scale: 2 }).default("0.00").notNull(),
  tasksCompleted: int("tasksCompleted").default(0).notNull(),
  lastActive: timestamp("lastActive"),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
});

export type Agent = typeof agents.$inferSelect;
export type InsertAgent = typeof agents.$inferInsert;

export const commands = mysqlTable("commands", {
  id: serial("id").primaryKey(),
  userId: bigint("userId", { mode: "number", unsigned: true }).notNull(),
  text: text("text").notNull(),
  status: mysqlEnum("status", ["pending", "processing", "completed", "failed"]).default("pending").notNull(),
  response: text("response"),
  executedBy: varchar("executedBy", { length: 255 }),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
});

export type Command = typeof commands.$inferSelect;
export type InsertCommand = typeof commands.$inferInsert;

export const contentPipeline = mysqlTable("content_pipeline", {
  id: serial("id").primaryKey(),
  userId: bigint("userId", { mode: "number", unsigned: true }).notNull(),
  agentId: bigint("agentId", { mode: "number", unsigned: true }),
  title: varchar("title", { length: 500 }).notNull(),
  type: mysqlEnum("type", ["youtube", "facebook", "website", "app"]).notNull(),
  status: mysqlEnum("status", ["draft", "generating", "review", "scheduled", "published"]).default("draft").notNull(),
  content: text("content"),
  metadata: json("metadata").$type<Record<string, any>>(),
  publishAt: timestamp("publishAt"),
  publishedAt: timestamp("publishedAt"),
  earnings: decimal("earnings", { precision: 12, scale: 2 }).default("0.00").notNull(),
  views: int("views").default(0).notNull(),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
});

export type ContentItem = typeof contentPipeline.$inferSelect;
export type InsertContentItem = typeof contentPipeline.$inferInsert;

export const systemMemory = mysqlTable("system_memory", {
  id: serial("id").primaryKey(),
  userId: bigint("userId", { mode: "number", unsigned: true }).notNull(),
  type: mysqlEnum("type", ["learning", "repair", "upgrade", "insight", "conversation"]).notNull(),
  content: text("content").notNull(),
  tags: json("tags").$type<string[]>(),
  importance: int("importance").default(5).notNull(),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
});

export type SystemMemory = typeof systemMemory.$inferSelect;
export type InsertSystemMemory = typeof systemMemory.$inferInsert;

export const analytics = mysqlTable("analytics", {
  id: serial("id").primaryKey(),
  userId: bigint("userId", { mode: "number", unsigned: true }).notNull(),
  date: date("date").notNull(),
  metric: mysqlEnum("metric", ["revenue", "views", "tasks", "efficiency", "latency"]).notNull(),
  value: decimal("value", { precision: 12, scale: 2 }).default("0.00").notNull(),
  source: varchar("source", { length: 255 }),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
});

export type Analytics = typeof analytics.$inferSelect;
export type InsertAnalytics = typeof analytics.$inferInsert;

export const platformConnections = mysqlTable("platform_connections", {
  id: serial("id").primaryKey(),
  userId: bigint("userId", { mode: "number", unsigned: true }).notNull(),
  platform: mysqlEnum("platform", ["youtube", "facebook", "twitter", "instagram", "website", "shopify"]).notNull(),
  credentials: json("credentials").$type<Record<string, any>>(),
  status: mysqlEnum("status", ["connected", "disconnected", "error"]).default("disconnected").notNull(),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
});

export type PlatformConnection = typeof platformConnections.$inferSelect;
export type InsertPlatformConnection = typeof platformConnections.$inferInsert;
