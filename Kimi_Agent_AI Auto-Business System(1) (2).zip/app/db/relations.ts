import { relations } from "drizzle-orm";
import { users, agents, commands, contentPipeline, systemMemory, analytics, platformConnections } from "./schema";

export const usersRelations = relations(users, ({ many }) => ({
  agents: many(agents),
  commands: many(commands),
  contentItems: many(contentPipeline),
  memory: many(systemMemory),
  analytics: many(analytics),
  platforms: many(platformConnections),
}));

export const agentsRelations = relations(agents, ({ one, many }) => ({
  user: one(users, { fields: [agents.userId], references: [users.id] }),
  contentItems: many(contentPipeline),
}));

export const commandsRelations = relations(commands, ({ one }) => ({
  user: one(users, { fields: [commands.userId], references: [users.id] }),
}));

export const contentPipelineRelations = relations(contentPipeline, ({ one }) => ({
  user: one(users, { fields: [contentPipeline.userId], references: [users.id] }),
  agent: one(agents, { fields: [contentPipeline.agentId], references: [agents.id] }),
}));

export const systemMemoryRelations = relations(systemMemory, ({ one }) => ({
  user: one(users, { fields: [systemMemory.userId], references: [users.id] }),
}));

export const analyticsRelations = relations(analytics, ({ one }) => ({
  user: one(users, { fields: [analytics.userId], references: [users.id] }),
}));

export const platformConnectionsRelations = relations(platformConnections, ({ one }) => ({
  user: one(users, { fields: [platformConnections.userId], references: [users.id] }),
}));
