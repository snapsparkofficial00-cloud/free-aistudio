import { getDb } from "../api/queries/connection";
import { agents, commands, contentPipeline, systemMemory, analytics, platformConnections } from "./schema";

async function seed() {
  const db = getDb();
  console.log("Seeding database...");

  // Seed agents
  await db.insert(agents).values([
    {
      userId: 1,
      name: "YouTube Synthesizer",
      type: "youtube" as const,
      status: "active" as const,
      description: "Automated video script generation, thumbnail creation, and publishing scheduler",
      config: { autoPublish: true, optimalHours: ["18:00", "20:00"], seoEnabled: true },
      earnings: "4250.00",
      tasksCompleted: 156,
      lastActive: new Date(),
    },
    {
      userId: 1,
      name: "Reel Amplifier",
      type: "facebook" as const,
      status: "active" as const,
      description: "Short-form content creation for Facebook Reels with viral optimization",
      config: { trendingAudio: true, autoCaption: true, crossPost: true },
      earnings: "3180.00",
      tasksCompleted: 203,
      lastActive: new Date(),
    },
    {
      userId: 1,
      name: "Site Architect",
      type: "website" as const,
      status: "active" as const,
      description: "Auto-builds landing pages, optimizes conversions, manages SEO",
      config: { framework: "nextjs", abTesting: true, autoSeo: true },
      earnings: "5620.00",
      tasksCompleted: 89,
      lastActive: new Date(),
    },
    {
      userId: 1,
      name: "App Forge",
      type: "app" as const,
      status: "learning" as const,
      description: "Mobile app generation with React Native and auto-deployment pipeline",
      config: { platform: "react-native", monetization: "freemium" },
      earnings: "1200.00",
      tasksCompleted: 34,
      lastActive: new Date(Date.now() - 86400000),
    },
    {
      userId: 1,
      name: "Capital Strategist",
      type: "trading" as const,
      status: "active" as const,
      description: "Revenue optimization and multi-stream income analysis",
      config: { riskLevel: "medium", autoReinvest: true },
      earnings: "8750.00",
      tasksCompleted: 267,
      lastActive: new Date(),
    },
    {
      userId: 1,
      name: "Repair Sentinel",
      type: "custom" as const,
      status: "active" as const,
      description: "Self-repair and system integrity monitoring agent",
      config: { scanInterval: 300, autoFix: true },
      earnings: "0.00",
      tasksCompleted: 412,
      lastActive: new Date(),
    },
  ]);

  // Seed commands
  await db.insert(commands).values([
    {
      userId: 1,
      text: "Create YouTube video about AI automation trends",
      status: "completed" as const,
      response: "YouTube automation sequence initialized. Created content pipeline with title generation, thumbnail optimization, and SEO tagging. Scheduling publication for optimal engagement window (6PM-9PM EST).",
      executedBy: "YouTube Synthesizer",
    },
    {
      userId: 1,
      text: "Generate Facebook Reels for affiliate marketing",
      status: "completed" as const,
      response: "Facebook Reels automation activated. Generated viral hooks, trending audio matching, and cross-platform adaptation. Short-form content pipeline ready with 3 reel variants.",
      executedBy: "Reel Amplifier",
    },
    {
      userId: 1,
      text: "Build landing page for SaaS product launch",
      status: "completed" as const,
      response: "Website auto-builder engaged. Deploying landing page with conversion-optimized layout, A/B testing framework, and analytics integration. Auto-SEO schema markup applied.",
      executedBy: "Site Architect",
    },
    {
      userId: 1,
      text: "Repair system integrity and patch vulnerabilities",
      status: "completed" as const,
      response: "Self-repair protocol activated. Scanning all agent modules for anomalies... 3 minor issues detected and patched. System integrity restored to 100%.",
      executedBy: "Repair Sentinel",
    },
    {
      userId: 1,
      text: "Show me revenue optimization strategies",
      status: "completed" as const,
      response: "Revenue optimization analysis complete. Identified 5 high-yield streams: affiliate automation (+$2.4K/mo), ad arbitrage (+$1.8K/mo), SaaS micro-tools (+$3.2K/mo), content monetization (+$4.1K/mo), trading signals (+$1.5K/mo).",
      executedBy: "Capital Strategist",
    },
  ]);

  // Seed content pipeline
  await db.insert(contentPipeline).values([
    {
      userId: 1,
      agentId: 1,
      title: "10 AI Tools That Print Money in 2026",
      type: "youtube" as const,
      status: "published" as const,
      content: "Video script about AI monetization tools...",
      metadata: { tags: ["ai", "money", "automation"], duration: "12:34" },
      publishedAt: new Date(Date.now() - 86400000),
      earnings: "450.00",
      views: 12500,
    },
    {
      userId: 1,
      agentId: 2,
      title: "This AI Makes $500/Day Passively",
      type: "facebook" as const,
      status: "published" as const,
      content: "Reel script with viral hooks...",
      metadata: { trending: true, reach: 45000 },
      publishedAt: new Date(Date.now() - 172800000),
      earnings: "320.00",
      views: 45000,
    },
    {
      userId: 1,
      agentId: 3,
      title: "Nexus Automata Landing Page",
      type: "website" as const,
      status: "published" as const,
      content: "Landing page with conversion optimization...",
      metadata: { conversion: 3.2, visitors: 8900 },
      publishedAt: new Date(Date.now() - 259200000),
      earnings: "1200.00",
      views: 8900,
    },
    {
      userId: 1,
      agentId: 1,
      title: "How I Automated My Entire Business",
      type: "youtube" as const,
      status: "review" as const,
      content: "Draft video script about business automation...",
      metadata: { seoScore: 92 },
      earnings: "0.00",
      views: 0,
    },
    {
      userId: 1,
      agentId: 4,
      title: "AI Side Hustle Mobile App",
      type: "app" as const,
      status: "generating" as const,
      content: "App specification document being generated...",
      metadata: { platform: "react-native" },
      earnings: "0.00",
      views: 0,
    },
  ]);

  // Seed system memory
  await db.insert(systemMemory).values([
    {
      userId: 1,
      type: "learning" as const,
      content: "Discovered optimal YouTube posting times: 6PM-9PM EST yields 34% higher engagement",
      tags: ["youtube", "optimization", "timing"],
      importance: 8,
    },
    {
      userId: 1,
      type: "repair" as const,
      content: "Fixed memory leak in Reel Amplifier agent. Root cause: unclosed database connections in batch processing loop",
      tags: ["bugfix", "reels", "performance"],
      importance: 9,
    },
    {
      userId: 1,
      type: "insight" as const,
      content: "Cross-platform content repurposing increases ROI by 280%. Facebook Reels → YouTube Shorts → TikTok pipeline is highest yield",
      tags: ["strategy", "roi", "cross-platform"],
      importance: 10,
    },
    {
      userId: 1,
      type: "upgrade" as const,
      content: "Applied v2.4 model upgrade to Capital Strategist. Risk assessment accuracy improved from 78% to 94%",
      tags: ["ml", "trading", "accuracy"],
      importance: 7,
    },
    {
      userId: 1,
      type: "conversation" as const,
      content: "User requested automated Shopify store creation with dropshipping integration",
      tags: ["shopify", "ecommerce", "request"],
      importance: 6,
    },
    {
      userId: 1,
      type: "learning" as const,
      content: "SEO keyword clustering shows 'AI automation' + 'passive income' combination has 4x search volume vs individual terms",
      tags: ["seo", "keywords", "content"],
      importance: 8,
    },
    {
      userId: 1,
      type: "repair" as const,
      content: "Self-healed network timeout in Site Architect. Switched to redundant API endpoints. Downtime: 0 seconds",
      tags: ["reliability", "network", "self-heal"],
      importance: 9,
    },
    {
      userId: 1,
      type: "insight" as const,
      content: "Website conversion rates peak at 3.8% when using AI-generated copy + human-reviewed CTAs vs 1.2% with pure AI",
      tags: ["conversion", "copywriting", "hybrid"],
      importance: 8,
    },
  ]);

  // Seed analytics (30 days of data)
  for (let i = 29; i >= 0; i--) {
    const date = new Date();
    date.setDate(date.getDate() - i);
    
    await db.insert(analytics).values([
      {
        userId: 1,
        date: date,
        metric: "revenue" as const,
        value: (Math.random() * 200 + 100).toFixed(2),
        source: "youtube_agent",
      },
      {
        userId: 1,
        date: date,
        metric: "revenue" as const,
        value: (Math.random() * 150 + 80).toFixed(2),
        source: "facebook_agent",
      },
      {
        userId: 1,
        date: date,
        metric: "views" as const,
        value: String(Math.floor(Math.random() * 2000 + 500)),
        source: "all",
      }
    ]);
  }

  // Seed platform connections
  await db.insert(platformConnections).values([
    { userId: 1, platform: "youtube" as const, status: "connected" as const, credentials: { channelId: "UC123" } },
    { userId: 1, platform: "facebook" as const, status: "connected" as const, credentials: { pageId: "fb456" } },
    { userId: 1, platform: "website" as const, status: "connected" as const, credentials: { domain: "nexusautomata.ai" } },
    { userId: 1, platform: "shopify" as const, status: "disconnected" as const, credentials: {} },
    { userId: 1, platform: "twitter" as const, status: "disconnected" as const, credentials: {} },
  ]);

  console.log("Seed complete!");
}

seed().catch(console.error);
