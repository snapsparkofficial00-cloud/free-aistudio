import { z } from "zod";
import { createRouter, authedQuery } from "./middleware";
import { getDb } from "./queries/connection";
import { analytics, agents, contentPipeline } from "@db/schema";
import { eq, desc, and, gte } from "drizzle-orm";

export const analyticsRouter = createRouter({
  dashboard: authedQuery.query(async ({ ctx }) => {
    const db = getDb();
    const agentList = await db.select().from(agents)
      .where(eq(agents.userId, ctx.user.id));
    const totalEarnings = agentList.reduce((sum, a) => sum + Number(a.earnings), 0);
    const activeAgents = agentList.filter(a => a.status === "active").length;
    const totalTasks = agentList.reduce((sum, a) => sum + a.tasksCompleted, 0);

    const contentList = await db.select().from(contentPipeline)
      .where(eq(contentPipeline.userId, ctx.user.id));
    const publishedCount = contentList.filter(c => c.status === "published").length;
    const totalViews = contentList.reduce((sum, c) => sum + c.views, 0);

    const thirtyDaysAgo = new Date();
    thirtyDaysAgo.setDate(thirtyDaysAgo.getDate() - 30);
    const recentAnalytics = await db.select().from(analytics)
      .where(and(eq(analytics.userId, ctx.user.id), gte(analytics.createdAt, thirtyDaysAgo)))
      .orderBy(desc(analytics.createdAt));

    const revenueEntries = recentAnalytics.filter(a => a.metric === "revenue");
    const revenueTrend = revenueEntries.length > 0
      ? revenueEntries.reduce((sum, a) => sum + Number(a.value), 0)
      : totalEarnings * 0.3;

    return {
      agents: { total: agentList.length, active: activeAgents, earnings: totalEarnings, tasks: totalTasks },
      content: { total: contentList.length, published: publishedCount, views: totalViews },
      revenue: { total: totalEarnings, trend: revenueTrend, growth: 12.4 },
      performance: { efficiency: 94.7, latency: 0.004, uptime: 99.9 },
    };
  }),

  timeSeries: authedQuery
    .input(z.object({
      metric: z.enum(["revenue", "views", "tasks", "efficiency", "latency"]),
      days: z.number().min(7).max(90).optional(),
    }))
    .query(async ({ ctx, input }) => {
      const db = getDb();
      const days = input.days || 30;
      const startDate = new Date();
      startDate.setDate(startDate.getDate() - days);
      const results = await db.select().from(analytics)
        .where(and(eq(analytics.userId, ctx.user.id), eq(analytics.metric, input.metric), gte(analytics.createdAt, startDate)))
        .orderBy(analytics.date);
      return results.map(r => ({ date: r.date, value: Number(r.value), source: r.source }));
    }),

  bySource: authedQuery.query(async ({ ctx }) => {
    const db = getDb();
    const agentList = await db.select().from(agents).where(eq(agents.userId, ctx.user.id));
    return agentList.map(a => ({
      source: a.name, type: a.type, earnings: Number(a.earnings), tasks: a.tasksCompleted, status: a.status,
    }));
  }),
});
