import { z } from "zod";
import { createRouter, authedQuery } from "./middleware";
import { getDb } from "./queries/connection";
import { agents } from "@db/schema";
import { eq, and, desc } from "drizzle-orm";

export const agentRouter = createRouter({
  list: authedQuery.query(async ({ ctx }) => {
    const db = getDb();
    const results = await db.select().from(agents)
      .where(eq(agents.userId, ctx.user.id))
      .orderBy(desc(agents.createdAt));
    return results;
  }),

  getById: authedQuery
    .input(z.object({ id: z.number() }))
    .query(async ({ ctx, input }) => {
      const db = getDb();
      const results = await db.select().from(agents)
        .where(and(eq(agents.id, input.id), eq(agents.userId, ctx.user.id)))
        .limit(1);
      return results[0] || null;
    }),

  create: authedQuery
    .input(z.object({
      name: z.string().min(1),
      type: z.enum(["youtube", "facebook", "website", "app", "trading", "custom"]),
      description: z.string().optional(),
      config: z.record(z.any()).optional(),
    }))
    .mutation(async ({ ctx, input }) => {
      const db = getDb();
      await db.insert(agents).values({
        userId: ctx.user.id,
        name: input.name,
        type: input.type,
        description: input.description || "",
        config: input.config || {},
      });
      return { success: true };
    }),

  update: authedQuery
    .input(z.object({
      id: z.number(),
      name: z.string().optional(),
      description: z.string().optional(),
      config: z.record(z.any()).optional(),
      status: z.enum(["active", "paused", "error", "learning"]).optional(),
    }))
    .mutation(async ({ ctx, input }) => {
      const db = getDb();
      const { id, ...data } = input;
      await db.update(agents)
        .set(data)
        .where(and(eq(agents.id, id), eq(agents.userId, ctx.user.id)));
      return { success: true };
    }),

  delete: authedQuery
    .input(z.object({ id: z.number() }))
    .mutation(async ({ ctx, input }) => {
      const db = getDb();
      await db.delete(agents)
        .where(and(eq(agents.id, input.id), eq(agents.userId, ctx.user.id)));
      return { success: true };
    }),

  toggleStatus: authedQuery
    .input(z.object({ id: z.number() }))
    .mutation(async ({ ctx, input }) => {
      const db = getDb();
      const results = await db.select().from(agents)
        .where(and(eq(agents.id, input.id), eq(agents.userId, ctx.user.id)))
        .limit(1);
      if (!results[0]) return { success: false };
      const newStatus = results[0].status === "active" ? "paused" : "active";
      await db.update(agents)
        .set({ status: newStatus, lastActive: new Date() })
        .where(eq(agents.id, input.id));
      return { success: true, status: newStatus };
    }),

  getStats: authedQuery.query(async ({ ctx }) => {
    const db = getDb();
    const allAgents = await db.select().from(agents)
      .where(eq(agents.userId, ctx.user.id));
    const active = allAgents.filter(a => a.status === "active").length;
    const totalEarnings = allAgents.reduce((sum, a) => sum + Number(a.earnings), 0);
    const totalTasks = allAgents.reduce((sum, a) => sum + a.tasksCompleted, 0);
    return {
      total: allAgents.length,
      active,
      paused: allAgents.filter(a => a.status === "paused").length,
      error: allAgents.filter(a => a.status === "error").length,
      learning: allAgents.filter(a => a.status === "learning").length,
      totalEarnings,
      totalTasks,
    };
  }),
});
