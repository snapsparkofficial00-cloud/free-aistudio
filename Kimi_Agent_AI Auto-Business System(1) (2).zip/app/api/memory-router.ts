import { z } from "zod";
import { createRouter, authedQuery } from "./middleware";
import { getDb } from "./queries/connection";
import { systemMemory } from "@db/schema";
import { eq, desc } from "drizzle-orm";

export const memoryRouter = createRouter({
  list: authedQuery
    .input(z.object({
      type: z.enum(["learning", "repair", "upgrade", "insight", "conversation"]).optional(),
      limit: z.number().min(1).max(100).optional(),
    }).optional())
    .query(async ({ ctx, input }) => {
      const db = getDb();
      const limit = input?.limit || 50;
      const results = await db.select().from(systemMemory)
        .where(eq(systemMemory.userId, ctx.user.id))
        .orderBy(desc(systemMemory.createdAt))
        .limit(limit);
      if (input?.type) return results.filter(r => r.type === input.type);
      return results;
    }),

  add: authedQuery
    .input(z.object({
      type: z.enum(["learning", "repair", "upgrade", "insight", "conversation"]),
      content: z.string().min(1),
      tags: z.array(z.string()).optional(),
      importance: z.number().min(1).max(10).optional(),
    }))
    .mutation(async ({ ctx, input }) => {
      const db = getDb();
      await db.insert(systemMemory).values({
        userId: ctx.user.id,
        type: input.type,
        content: input.content,
        tags: input.tags || [],
        importance: input.importance || 5,
      });
      return { success: true };
    }),

  getInsights: authedQuery.query(async ({ ctx }) => {
    const db = getDb();
    const allMemory = await db.select().from(systemMemory)
      .where(eq(systemMemory.userId, ctx.user.id))
      .orderBy(desc(systemMemory.createdAt))
      .limit(100);
    const byType: Record<string, number> = {};
    allMemory.forEach(m => { byType[m.type] = (byType[m.type] || 0) + 1; });
    const insights = allMemory.filter(m => m.importance >= 7).slice(0, 10);
    return { total: allMemory.length, byType, insights, recent: allMemory.slice(0, 5) };
  }),
});
