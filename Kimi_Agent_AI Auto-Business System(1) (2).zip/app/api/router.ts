import { authRouter } from "./auth-router";
import { agentRouter } from "./agent-router";
import { commandRouter } from "./command-router";
import { contentRouter } from "./content-router";
import { memoryRouter } from "./memory-router";
import { analyticsRouter } from "./analytics-router";
import { platformRouter } from "./platform-router";
import { createRouter, publicQuery } from "./middleware";

export const appRouter = createRouter({
  ping: publicQuery.query(() => ({ ok: true, ts: Date.now() })),
  auth: authRouter,
  agent: agentRouter,
  command: commandRouter,
  content: contentRouter,
  memory: memoryRouter,
  analytics: analyticsRouter,
  platform: platformRouter,
});

export type AppRouter = typeof appRouter;
