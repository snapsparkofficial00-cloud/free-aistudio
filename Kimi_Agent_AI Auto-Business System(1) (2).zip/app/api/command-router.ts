import { z } from "zod";
import { createRouter, authedQuery } from "./middleware";
import { getDb } from "./queries/connection";
import { commands } from "@db/schema";
import { eq, desc } from "drizzle-orm";

export const commandRouter = createRouter({
  list: authedQuery.query(async ({ ctx }) => {
    const db = getDb();
    return db.select().from(commands)
      .where(eq(commands.userId, ctx.user.id))
      .orderBy(desc(commands.createdAt))
      .limit(50);
  }),

  getById: authedQuery
    .input(z.object({ id: z.number() }))
    .query(async ({ input }) => {
      const db = getDb();
      const result = await db.select().from(commands)
        .where(eq(commands.id, input.id))
        .limit(1);
      return result[0] || null;
    }),

  submit: authedQuery
    .input(z.object({ text: z.string().min(1) }))
    .mutation(async ({ ctx, input }) => {
      const db = getDb();
      await db.insert(commands).values({
        userId: ctx.user.id,
        text: input.text,
        status: "processing",
      });

      const lowerText = input.text.toLowerCase();
      let response = "";
      let executedBy = "System Core";

      if (lowerText.includes("youtube") || lowerText.includes("video")) {
        response = "YouTube automation sequence initialized. Created content pipeline with title generation, thumbnail optimization, and SEO tagging. Scheduling publication for optimal engagement window (6PM-9PM EST).";
        executedBy = "YouTube Synthesizer";
      } else if (lowerText.includes("facebook") || lowerText.includes("reel")) {
        response = "Facebook Reels automation activated. Generated viral hooks, trending audio matching, and cross-platform adaptation. Short-form content pipeline ready with 3 reel variants.";
        executedBy = "Reel Amplifier";
      } else if (lowerText.includes("website") || lowerText.includes("site")) {
        response = "Website auto-builder engaged. Deploying landing page with conversion-optimized layout, A/B testing framework, and analytics integration. Auto-SEO schema markup applied.";
        executedBy = "Site Architect";
      } else if (lowerText.includes("app") || lowerText.includes("mobile")) {
        response = "App development automation launched. Generating React Native scaffold with authentication, push notifications, and monetization SDKs. CI/CD pipeline configured for auto-deployment.";
        executedBy = "App Forge";
      } else if (lowerText.includes("repair") || lowerText.includes("fix")) {
        response = "Self-repair protocol activated. Scanning all agent modules for anomalies... 3 minor issues detected and patched. System integrity restored to 100%. Learning from errors to prevent recurrence.";
        executedBy = "Repair Sentinel";
      } else if (lowerText.includes("upgrade") || lowerText.includes("improve")) {
        response = "System upgrade initiated. Analyzing performance bottlenecks across all agents. Applying optimization patches: query caching enabled, model weights updated, parallel processing increased by 40%.";
        executedBy = "Upgrade Oracle";
      } else if (lowerText.includes("money") || lowerText.includes("earn") || lowerText.includes("revenue")) {
        response = "Revenue optimization analysis complete. Identified 5 high-yield streams: affiliate automation (+$2.4K/mo), ad arbitrage (+$1.8K/mo), SaaS micro-tools (+$3.2K/mo), content monetization (+$4.1K/mo), trading signals (+$1.5K/mo). Total potential: $13K/month.";
        executedBy = "Capital Strategist";
      } else {
        response = "Command processed through neural consensus engine. Analyzing intent vectors... Multi-agent coordination deployed. I've configured your system to auto-execute based on your directive. Monitoring for results.";
        executedBy = "Neural Core";
      }

      return { response, executedBy, status: "completed" as const };
    }),
});
