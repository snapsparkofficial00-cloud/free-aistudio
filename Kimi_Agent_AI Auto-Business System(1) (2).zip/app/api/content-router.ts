import { z } from "zod";
import { createRouter, authedQuery } from "./middleware";
import { getDb } from "./queries/connection";
import { contentPipeline } from "@db/schema";
import { eq, and, desc } from "drizzle-orm";

export const contentRouter = createRouter({
  list: authedQuery
    .input(z.object({
      status: z.enum(["draft", "generating", "review", "scheduled", "published"]).optional(),
      type: z.enum(["youtube", "facebook", "website", "app"]).optional(),
    }).optional())
    .query(async ({ ctx, input }) => {
      const db = getDb();
      const results = await db.select().from(contentPipeline)
        .where(eq(contentPipeline.userId, ctx.user.id))
        .orderBy(desc(contentPipeline.createdAt));
      if (input?.status) return results.filter(r => r.status === input.status);
      if (input?.type) return results.filter(r => r.type === input.type);
      return results;
    }),

  create: authedQuery
    .input(z.object({
      title: z.string().min(1),
      type: z.enum(["youtube", "facebook", "website", "app"]),
      agentId: z.number().optional(),
    }))
    .mutation(async ({ ctx, input }) => {
      const db = getDb();
      await db.insert(contentPipeline).values({
        userId: ctx.user.id,
        agentId: input.agentId || null,
        title: input.title,
        type: input.type,
      });
      return { success: true };
    }),

  generate: authedQuery
    .input(z.object({ id: z.number() }))
    .mutation(async ({ ctx, input }) => {
      const db = getDb();
      const existing = await db.select().from(contentPipeline)
        .where(and(eq(contentPipeline.id, input.id), eq(contentPipeline.userId, ctx.user.id)))
        .limit(1);
      if (!existing[0]) return { success: false };

      await db.update(contentPipeline)
        .set({ status: "generating" })
        .where(eq(contentPipeline.id, input.id));

      const templates: Record<string, string> = {
        youtube: `## Video Script: "${existing[0].title}"\n\n**Hook (0-15s):** "What if I told you the system running right now is making money while you sleep?"\n\n**Intro (15-45s):** Today we're diving deep into autonomous revenue streams. This isn't theory.\n\n**Main Content:**\n- Break down the automation architecture\n- Show real earnings screenshots\n- Explain the multi-agent consensus model\n\n**CTA:** Subscribe and comment "AUTOMATE" to get the blueprint.\n\n**Tags:** #ai #automation #passiveincome`,
        facebook: `## Reel Script: "${existing[0].title}"\n\n**Visual:** Fast-paced montage of dashboard, charts, money counters\n**Audio:** Trending electronic beat\n**Text overlays:**\n- "Day 1: $0"\n- "Day 30: $4,200"\n- "All automated"\n\n**Caption:** This AI system runs 24/7 creating content and scaling revenue. Zero manual work. 🤖💰\n\n#reels #viral #ai #passiveincome`,
        website: `## Landing Page: "${existing[0].title}"\n\n**Hero Section:**\n- Headline: "Turn Your Ideas Into Automated Income"\n- Subhead: "AI-powered system that builds, optimizes, and scales"\n- CTA: "Start Automating"\n\n**Features Grid:**\n1. Multi-Agent Coordination\n2. Self-Learning Optimization\n3. Auto-Publish Across Platforms\n4. Real-Time Analytics\n\n**Pricing:** Free tier + Pro $49/mo`,
        app: `## App Spec: "${existing[0].title}"\n\n**Core Features:**\n- AI Command Center (voice + text)\n- Real-time Earnings Dashboard\n- Multi-Platform Publisher\n- Agent Management Console\n\n**Tech Stack:**\n- React Native + TypeScript\n- Node.js backend with tRPC\n- OpenAI integration\n\n**Monetization:**\n- Freemium model\n- In-app upgrades`,
      };

      const content = templates[existing[0].type] || `Generated content for: ${existing[0].title}`;
      await db.update(contentPipeline)
        .set({ status: "review", content })
        .where(eq(contentPipeline.id, input.id));
      return { success: true, content };
    }),

  update: authedQuery
    .input(z.object({
      id: z.number(),
      title: z.string().optional(),
      content: z.string().optional(),
      status: z.enum(["draft", "generating", "review", "scheduled", "published"]).optional(),
      metadata: z.record(z.any()).optional(),
    }))
    .mutation(async ({ ctx, input }) => {
      const db = getDb();
      const { id, ...data } = input;
      await db.update(contentPipeline)
        .set(data)
        .where(and(eq(contentPipeline.id, id), eq(contentPipeline.userId, ctx.user.id)));
      return { success: true };
    }),

  publish: authedQuery
    .input(z.object({ id: z.number() }))
    .mutation(async ({ ctx, input }) => {
      const db = getDb();
      await db.update(contentPipeline)
        .set({ status: "published", publishedAt: new Date() })
        .where(and(eq(contentPipeline.id, input.id), eq(contentPipeline.userId, ctx.user.id)));
      return { success: true };
    }),

  delete: authedQuery
    .input(z.object({ id: z.number() }))
    .mutation(async ({ ctx, input }) => {
      const db = getDb();
      await db.delete(contentPipeline)
        .where(and(eq(contentPipeline.id, input.id), eq(contentPipeline.userId, ctx.user.id)));
      return { success: true };
    }),
});
