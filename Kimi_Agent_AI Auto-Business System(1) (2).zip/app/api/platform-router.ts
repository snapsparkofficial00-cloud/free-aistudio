import { z } from "zod";
import { createRouter, authedQuery } from "./middleware";
import { getDb } from "./queries/connection";
import { platformConnections } from "@db/schema";
import { eq, and } from "drizzle-orm";

export const platformRouter = createRouter({
  list: authedQuery.query(async ({ ctx }) => {
    const db = getDb();
    return db.select().from(platformConnections)
      .where(eq(platformConnections.userId, ctx.user.id))
      .orderBy(platformConnections.createdAt);
  }),

  connect: authedQuery
    .input(z.object({
      platform: z.enum(["youtube", "facebook", "twitter", "instagram", "website", "shopify"]),
      credentials: z.record(z.any()).optional(),
    }))
    .mutation(async ({ ctx, input }) => {
      const db = getDb();
      const existing = await db.select().from(platformConnections)
        .where(and(eq(platformConnections.userId, ctx.user.id), eq(platformConnections.platform, input.platform)))
        .limit(1);
      if (existing[0]) {
        await db.update(platformConnections)
          .set({ status: "connected", credentials: input.credentials || {} })
          .where(eq(platformConnections.id, existing[0].id));
        return { id: existing[0].id, status: "connected" as const };
      }
      await db.insert(platformConnections).values({
        userId: ctx.user.id, platform: input.platform, credentials: input.credentials || {}, status: "connected",
      });
      return { id: 0, status: "connected" as const };
    }),

  disconnect: authedQuery
    .input(z.object({ id: z.number() }))
    .mutation(async ({ ctx, input }) => {
      const db = getDb();
      await db.update(platformConnections)
        .set({ status: "disconnected" })
        .where(and(eq(platformConnections.id, input.id), eq(platformConnections.userId, ctx.user.id)));
      return { success: true };
    }),

  test: authedQuery
    .input(z.object({ id: z.number() }))
    .mutation(async () => {
      await new Promise(resolve => setTimeout(resolve, 1000));
      return { success: true, latency: Math.random() * 200 + 50 };
    }),
});
